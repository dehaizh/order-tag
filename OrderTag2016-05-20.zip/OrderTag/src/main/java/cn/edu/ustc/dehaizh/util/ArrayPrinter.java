package cn.edu.ustc.dehaizh.util;

import java.util.Arrays;

/**
 * Created by dehaizh on 2016/4/26.
 */
public class ArrayPrinter {

    public static void print(int[] arr)
    {
        System.out.println(Arrays.toString(arr));
    }

    public static void print(Object[] arr)
    {
        System.out.println( Arrays.toString(arr) );
    }

}
