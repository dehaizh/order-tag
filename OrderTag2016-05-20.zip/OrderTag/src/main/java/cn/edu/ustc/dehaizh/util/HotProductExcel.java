package cn.edu.ustc.dehaizh.util;

import cn.edu.ustc.dehaizh.domain.HotCommodity;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.*;
import java.util.List;

/**
 * Created by Administrator on 2015/9/17.
 */

public class HotProductExcel {

    //并不能初始化OrderService，故此作废

    public static void makeOrderExcel(List<HotCommodity> producrList, String ExcelPath){
        System.out.println("-------------------begin excel---------------");
        HSSFWorkbook wb = new HSSFWorkbook();
        //生成一个sheet1
        HSSFSheet sheet = wb.createSheet("热门商品");
        //为sheet1生成第一行，用于放表头信息
        HSSFRow row = sheet.createRow(0);

        //第一行的第一个单元格的值为  ‘序号’
        //订单编号 	店铺（ID） 	下单时间 	完成时间 	收货人
        // 收货地区 	开发票 	订单金额 	订单状态
        HSSFCell cell = row.createCell(0);
        cell.setCellValue("商品名称");

        cell = row.createCell(1);
        cell.setCellValue("卖出数量");


        //获得List中的数据，并将数据放到Excel中

        for(int i=0;i<producrList.size();i++)
        {
            HotCommodity hotCommodity = producrList.get(i);

            //数据每增加一行，表格就再生成一行

            row = sheet.createRow(i+1);
            //第一个单元格，放序号随着i的增加而增加

            //订单编号 	店铺（ID） 	下单时间 	完成时间
            // 收货人
            // 收货地区 	开发票 	订单金额 	订单状态

            //第yi个单元格放firstname
            cell = row.createCell(0);
            cell.setCellValue(hotCommodity.getCommodity());
            //第三个单元格放lastname
            cell = row.createCell(1);
            cell.setCellValue(hotCommodity.getCnt());


        }


        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try
        {
            wb.write(os);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        byte[] content = os.toByteArray();

        File file = new File(ExcelPath);//Excel文件生成后存储的位置。

        OutputStream fos  = null;

        try
        {
            fos = new FileOutputStream(file);

            fos.write(content);

            os.close();

            fos.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {

//        List<Order> orderList =new ArrayList<Order>();
//        String ExcelPath="D:"+File.pathSeparator+"adminReport.xls";
//        baseExcel.makeOrderExcel(orderList,ExcelPath);
    }

}
