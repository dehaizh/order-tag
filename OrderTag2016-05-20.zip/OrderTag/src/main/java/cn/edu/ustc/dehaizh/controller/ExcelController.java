package cn.edu.ustc.dehaizh.controller;


import cn.edu.ustc.dehaizh.orders.OrderExcel2DB;
import cn.edu.ustc.dehaizh.orders.ReceiptExcel2DB;
import cn.edu.ustc.dehaizh.xlsx.DirectoryUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by songyinlong on 16/4/19.
 */
@Controller
@RequestMapping("/yuntu")
public class ExcelController {


    @RequestMapping("")
    public String toUploadExcel(){
        return "uploadExcel";
    }

    @RequestMapping("/uploadExcel/wmorders")
    @ResponseBody
    public String uploadExcel(HttpSession session, @RequestParam(value = "file",required = true)MultipartFile[] file
    , HttpServletResponse response, HttpServletRequest request) throws Exception {

        System.out.println("----------------------");

        String filePath = session.getServletContext().getRealPath("/")+"WmOrders"+File.separator;


        File dir=new File(filePath);
        if (dir.exists()==false) dir.mkdir();

        System.out.println("Excel文件地址："+filePath);


        for(int i = 0;i<file.length;i++){
            System.out.println("fileName---------->" + file[i].getOriginalFilename());

            if(!file[i].isEmpty()){

                try {
                    //拿到输出流，同时重命名上传的文件
                    FileOutputStream os = new FileOutputStream(filePath+ file[i].getOriginalFilename());
                    //拿到上传文件的输入流
                    FileInputStream in = (FileInputStream) file[i].getInputStream();

                    //以写字节的方式写文件
                    int b = 0;
                    while((b=in.read()) != -1){
                        os.write(b);
                    }
                    os.flush();
                    os.close();
                    in.close();

                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("上传出错");
                }
            }
        }


        String result= new String("<h1>上传成功，点击链接分析结果</h1>" +
                "<a href=\"yuntu/analyzeResult/wmorders\" target=\"messageFrame\"><h1>分析上传的账单文件</h1></a>".getBytes());


        request.setCharacterEncoding("utf-8");  //这里不设置编码会有乱码
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Cache-Control", "no-cache");
        PrintWriter out = response.getWriter();  //输出中文，这一句一定要放到response.setContentType("text/html;charset=utf-8"),  response.setHeader("Cache-Control", "no-cache")后面，否则中文返回到页面是乱码
        out.print(result);
        out.flush();
        out.close();

        return null;

    }

    //以下提交分析该文档的代码
    @RequestMapping("/analyzeResult/wmorders")
    public String uploadExcel(HttpSession session) {
        String filePath = session.getServletContext().getRealPath("/")+"WmOrders"+File.separator;
        String fileExt = "*";
        try {
            OrderExcel2DB.file2DB(filePath, fileExt);
        } catch (IOException e) {
            e.printStackTrace();
        }


        //分析完文件，重命名该文件夹
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String nowDate= formatter.format(new Date());
        String newpath=session.getServletContext().getRealPath("/")+"WmOrders_"+nowDate+File.separator;
        DirectoryUtil.renameDirectory(filePath,newpath);
        System.out.println("----------"+newpath);
        System.out.println("Finished...");
        return "analyzeResult";
    }


    @RequestMapping("/uploadExcel/wmOrdersReceipt")
    @ResponseBody
    public String uploadExcelWmOrdersReceipt(HttpSession session,@RequestParam(value = "file_return",required = true)MultipartFile[] file
            , HttpServletResponse response, HttpServletRequest request) throws Exception {

        System.out.println("----------------------");

        String filePath = session.getServletContext().getRealPath("/")+"wmOrdersReceipt"+File.separator;


        File dir=new File(filePath);
        if (dir.exists()==false) dir.mkdir();

        System.out.println("Excel文件地址："+filePath);


        for(int i = 0;i<file.length;i++){
            System.out.println("fileName---------->" + file[i].getOriginalFilename());

            if(!file[i].isEmpty()){

                try {
                    //拿到输出流，同时重命名上传的文件
                    FileOutputStream os = new FileOutputStream(filePath+ file[i].getOriginalFilename());
                    //拿到上传文件的输入流
                    FileInputStream in = (FileInputStream) file[i].getInputStream();

                    //以写字节的方式写文件
                    int b = 0;
                    while((b=in.read()) != -1){
                        os.write(b);
                    }
                    os.flush();
                    os.close();
                    in.close();

                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("上传出错");
                }
            }
        }


        String result=  "<h1>上传成功，点击链接分析结果</h1>" +
                "<a href=\"yuntu/analyzeResult/wmOrdersReceipt\" target=\"messageFrame\"><h1>分析上传回执的文件</h1></a>";

        request.setCharacterEncoding("utf-8");  //这里不设置编码会有乱码
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Cache-Control", "no-cache");
        PrintWriter out = response.getWriter();  //输出中文，这一句一定要放到response.setContentType("text/html;charset=utf-8"),  response.setHeader("Cache-Control", "no-cache")后面，否则中文返回到页面是乱码
        out.print(result);
        out.flush();
        out.close();

        return null;

    }

    //以下提交分析该文档的代码
    @RequestMapping("/analyzeResult/wmOrdersReceipt")
    public String analyzewmOrdersReceipt(HttpSession session) {
        String filePath = session.getServletContext().getRealPath("/")+"wmOrdersReceipt"+File.separator;
        String fileExt = "*";
        try {
            ReceiptExcel2DB.file2DB(filePath, fileExt);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //分析完文件，重命名该文件夹
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String nowDate= formatter.format(new Date());
        String newpath=session.getServletContext().getRealPath("/")+"wmOrdersReceipt"+nowDate+File.separator;
        DirectoryUtil.renameDirectory(filePath,newpath);
        System.out.println("----------"+newpath);
        System.out.println("Finished...");
        return "analyzeResult";
    }

    }
