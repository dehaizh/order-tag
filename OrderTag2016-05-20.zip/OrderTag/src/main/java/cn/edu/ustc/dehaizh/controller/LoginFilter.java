package cn.edu.ustc.dehaizh.controller;

import cn.edu.ustc.dehaizh.domain.User;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 该过滤器用于登陆控制，
 * 过滤未登陆的用户，以及放行登陆操作
 * Created by dehaizh on 2016/3/30.
 */
public class LoginFilter implements Filter {

    public void init(FilterConfig filterConfig) throws ServletException {

    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest request =(HttpServletRequest)req;
        HttpServletResponse response=(HttpServletResponse)resp;
        User user = (User) request.getSession().getAttribute("user");
        String uri = request.getRequestURI();
//        String username = user.getUsername();
        System.out.println("URI:"+uri);
        if(user!=null)
            System.out.println("Session 不为空");
        else
            System.out.println("Session 为空");

        if(user == null)
//        if(user == null && !(uri.contains("/mail-autoreply/") || uri.contains("/mail-autoreply/login") || uri.contains("/mail-autoreply/toLogin")))
        {
            if( !(uri.contains("/order-tag/resources/") || uri.contains("/order-tag/login") || uri.contains("/order-tag/toLogin"))) {
                System.out.println("未登陆，重定向到/order-tag/login");
                response.sendRedirect(request.getContextPath() + "/login");
            }
        }

        //
        request.getSession().setAttribute("IP", request.getRemoteAddr());

        //
        chain.doFilter(request, response);

    }

    public void destroy() {

    }
}
