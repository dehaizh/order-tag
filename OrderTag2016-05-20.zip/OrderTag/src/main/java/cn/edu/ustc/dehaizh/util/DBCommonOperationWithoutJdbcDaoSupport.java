package cn.edu.ustc.dehaizh.util;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ArrayListHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by dehaizh on 2016/3/17.
 */
@Transactional
public class DBCommonOperationWithoutJdbcDaoSupport {

    /**
     * 空集合
     */
    private static final ArrayList<Object[]> EMPTY_ARRAY_LIST = new ArrayList<Object[]>();
    /**
     * 工具包DBUtils中的QueryRunnner对象
     */
    private static final QueryRunner qr = new QueryRunner();

    /**
     * 该方法用来调用没有返回值的存储过程，但是
     * @param procName 必须是包含{}的存储过程的完整名字，比如，{call sp_join_orders_receipt()}
     * @param params
     * @return
     */
    public static boolean callNonQuery(String procName,ArrayList<Object> params)
    {

        boolean ret = false;
        Connection conn = null;
        conn = DBConnection.getDBConnection();
        if(conn != null)
        {
            try {
                //开启事务
                conn.setAutoCommit(false);
                int rows = 0;
                CallableStatement callableStatement = conn.prepareCall(procName);
                if(params!=null&&params.size()>0)
                {
                    int numOfColums = params.size();
                    for(int i=1;i<=numOfColums;++i)
                    callableStatement.setObject(i,params.get(i-1));
                }
                callableStatement.execute();
                conn.commit();

                ret = true;
                System.out.println("影响的行数_"+rows);
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                try {
                    //异常 回滚
                    conn.rollback();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }finally{
                if(conn!=null)
                    try {
                        //关闭数据库连接
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }

        }
        return ret;

    }

    /**
     * 该函数用来调用包含有返回指定存储过程
     * @param procName 必须是包含{}的存储过程的完整名字，比如，{call sp_join_orders_receipt()}
     * @param params ArrayList<Object>列表
     * @return ArrayList<Object[]>，一个Object[]表示一行记录
     */
    public static ArrayList<Object[]> callQuery(String procName,ArrayList<Object> params)
    {

       ArrayList<Object[]> ret = new ArrayList<Object[]>();
        Connection conn = null;
        conn = DBConnection.getDBConnection();
        if(conn != null)
        {
            try {
                conn.setAutoCommit(false);
                int rows = 0;
                CallableStatement callableStatement = conn.prepareCall(procName);
                if(params!=null&&params.size()>0)
                {
                    int numOfColums = params.size();
                    for(int i=1;i<=numOfColums;++i)
                        callableStatement.setObject(i,params.get(i-1));
                }

                //获取结果集
                ResultSet resultSet = callableStatement.executeQuery();
                //获取结果集中列的数目
                int colNum = resultSet.getMetaData().getColumnCount();
                while (resultSet.next())
                {
                    Object[] record = new Object[colNum];
                    for(int i=0;i<colNum;++i)
                        record[i] = resultSet.getObject(i+1);

                    ret.add(record);
                }

            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                try {
                    //异常 回滚
                    conn.rollback();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }finally{
                if(conn!=null)
                    try {
                        //关闭数据库连接
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }

        }
        return ret;

    }

    /**
     * batch operation,such as dumping the csv file into db
     *
     * @param sql
     * @param params
     */
        public static int[] batch(String sql, ArrayList<Object[]> params)
        {
            int[] counts=null;
            Connection conn = null;
            conn = DBConnection.getDBConnection();
            try {
                conn.setAutoCommit(false);
                PreparedStatement pstmt = conn.prepareStatement(sql);
                //pstmt.execute("SET NAMES 'utf8'");
                if(params!=null && params.size()>0)
                {
                    Object[] firstRow = params.get(0);
                    int numOfColumns = firstRow.length;
                    //int hangHao=1;
                    int numOfRows = 0;
                    for(Object[] row:params)
                    {
                        //System.out.println("第"+hangHao+"行——"+Arrays.toString(row));
                        //hangHao++;
                        for(int i=1; i<=numOfColumns; ++i)
                        {
                            //PreparedStatement操作数据库时，下标是从1开始的
                            pstmt.setObject(i, row[i-1]);
                        }
                        pstmt.addBatch();

                        //分段批处理
                        ++numOfRows;
                        if(numOfRows%300==0)
                        {
                            pstmt.executeBatch();
                            pstmt.clearBatch();
                        }
                    }
                    counts = pstmt.executeBatch();
                    pstmt.clearBatch();
                    conn.commit();
                }
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                try {
                    conn.rollback();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }finally{
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            return counts;
        }

    /**
     * 该函数执行不带sql返回值的sql语句，比如delete、update等等
     * @param sql	传入的PreparedStatement类型的sql参数
     * @param params	sql语句中需要的参数值，按照顺序存放在ArrayList中
     * @return	成功执行则返回true，有错或者异常则返回false
     */
    public static boolean executeNonQuery(String sql, ArrayList<Object> params)
    {
        boolean ret = false;
        Connection conn = null;
        conn = DBConnection.getDBConnection();
        if(conn != null)
        {
            try {
                //开启事务
                conn.setAutoCommit(false);
                int rows = 0;
                if(params!=null && params.size()>0)
                    rows = qr.update(conn, sql, params.toArray());
                else {
                    rows = qr.update(conn, sql);
                }
                conn.commit();
                if(rows>0)
                    ret = true;
                System.out.println("影响的行数_"+rows);
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                try {
                    //异常 回滚
                    conn.rollback();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }finally{
                if(conn!=null)
                    try {
                        //关闭数据库连接
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }

        }
        return ret;
    }

    /**
     *
     * @param sql
     * @param params
     * @return 查找的数据组成ArrayList<Object[]>列表，如果没有查找的数据，则返回一个空的ArrayList<Object[]>,而不是放回null
     */
    public static ArrayList<Object[]> executeQuery(String sql, ArrayList<Object> params)
    {
        ArrayList<Object[]> result = EMPTY_ARRAY_LIST;
        Connection conn = null;
        conn = DBConnection.getDBConnection();
        if(conn != null)
        {
            try {
                if (params!=null && params.size()>0) {
                    result = (ArrayList<Object[]>) qr.query(conn, sql, new ArrayListHandler(), params.toArray());
                }
                else {
                    result = (ArrayList<Object[]>) qr.query(conn, sql, new ArrayListHandler());
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }finally{
                if(conn!=null)
                    try {
                        //关闭数据库连接
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }

        }

        return result;
    }

}
