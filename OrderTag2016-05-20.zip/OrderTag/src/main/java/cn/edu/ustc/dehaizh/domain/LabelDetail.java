package cn.edu.ustc.dehaizh.domain;

/**
 * Created by root on 16-5-9.
 */
public class LabelDetail {
    private Integer customerId;
    private String labelDetail;
    private String cGender;
    private String cName;
    private Integer cAge;
    private String cIdNo;
    private String cPhone;
    private Integer cTotalSum;
    private String cProvince;
    private String cCity;
    private String cAddress;

    public LabelDetail() {
    }

    public LabelDetail(Integer customerId, String labelDetail, String cGender, String cName, Integer cAge, String cIdNo, String cPhone, Integer cTotalSum, String cProvince, String cCity, String cAddress) {
        this.customerId = customerId;
        this.labelDetail = labelDetail;
        this.cGender = cGender;
        this.cName = cName;
        this.cAge = cAge;
        this.cIdNo = cIdNo;
        this.cPhone = cPhone;
        this.cTotalSum = cTotalSum;
        this.cProvince = cProvince;
        this.cCity = cCity;
        this.cAddress = cAddress;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getLabelDetail() {
        return labelDetail;
    }

    public void setLabelDetail(String labelDetail) {
        this.labelDetail = labelDetail;
    }

    public String getcGender() {
        return cGender;
    }

    public void setcGender(String cGender) {
        this.cGender = cGender;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public Integer getcAge() {
        return cAge;
    }

    public void setcAge(Integer cAge) {
        this.cAge = cAge;
    }

    public String getcIdNo() {
        return cIdNo;
    }

    public void setcIdNo(String cIdNo) {
        this.cIdNo = cIdNo;
    }

    public String getcPhone() {
        return cPhone;
    }

    public void setcPhone(String cPhone) {
        this.cPhone = cPhone;
    }

    public Integer getcTotalSum() {
        return cTotalSum;
    }

    public void setcTotalSum(Integer cTotalSum) {
        this.cTotalSum = cTotalSum;
    }

    public String getcProvince() {
        return cProvince;
    }

    public void setcProvince(String cProvince) {
        this.cProvince = cProvince;
    }

    public String getcCity() {
        return cCity;
    }

    public void setcCity(String cCity) {
        this.cCity = cCity;
    }

    public String getcAddress() {
        return cAddress;
    }

    public void setcAddress(String cAddress) {
        this.cAddress = cAddress;
    }
}
