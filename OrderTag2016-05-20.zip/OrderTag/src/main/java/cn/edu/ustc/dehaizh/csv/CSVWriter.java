package cn.edu.ustc.dehaizh.csv;

import java.io.*;
import java.util.ArrayList;

public class CSVWriter {

	/**
	 * 该函数用来将参数为ArrayList<Object[]>类型的list写入到指定的文件中
	 * @param list
	 * @param dest
	 * @throws IOException
	 */
	public static void saveArrayObject(ArrayList<Object[]> list, String dest) throws IOException
	{
		File file  = new File(dest);
		OutputStreamWriter out = null;
		BufferedWriter writer = null;
		try {
			//此处必须使用"GB2312",不然会出现中文乱码问题
			out = new OutputStreamWriter(new FileOutputStream(file), "GB2312");
			writer = new BufferedWriter(out);
			for(Object[] row:list)
			{
//				for(Object elememt:row)
//				{
//					//给每个字段添加双引号输出
//					writer.write("\""+elememt+"\""+",");
//				}

				int cols = row.length;
				for(int i=0;i<cols-1;++i)
					writer.write(row[i]+",");
				writer.write(row[cols-1].toString());
				writer.newLine();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally
		{//关闭输出流
			if(writer!=null)
				writer.close();
			if(out !=null)
				out.close();
		}	
		
	}
	/**
	 * 待写出的数据是一个一维表形式
	 * @param list 待写入到csv文件中的ArrayList<String>，每个条目都是一个用逗号隔开的String
	 * @param dest 文件的全路径名
	 * @throws IOException 文件路径不合法
	 */
	public static void save(ArrayList<String> list, String dest) throws IOException
	{
		File file  = new File(dest);
		OutputStreamWriter out = null;
		BufferedWriter writer = null;
		try {
			//此处必须使用"GB2312",不然会出现中文乱码问题
			out = new OutputStreamWriter(new FileOutputStream(file), "GB2312");
			writer = new BufferedWriter(out);
			for(String element :list)
			{
				//给每个字段添加双引号输出
				writer.write("\""+element+"\""+",");
				writer.newLine();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally
		{//关闭输出流
			if(writer!=null)
				writer.close();
			if(out !=null)
				out.close();
		}	
	}
	
	/**
	 * 待写出的参数是一个二维表的形式
	 * @param list
	 * @param dest
	 * @throws IOException
	 */
	public static void saveArray2(ArrayList<ArrayList<String>> list, String dest) throws IOException
	{
		File file  = new File(dest);
		OutputStreamWriter out = null;
		BufferedWriter writer = null;
		try {
			//此处必须使用"GB2312",不然会出现中文乱码问题
			out = new OutputStreamWriter(new FileOutputStream(file), "GB2312");
			writer = new BufferedWriter(out);
			for(ArrayList<String> rowlist :list)
			{
				for(String element :rowlist)
					//给每个字段添加双引号输出
					writer.write("\""+element+"\""+",");
				
				writer.newLine();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally
		{//关闭输出流
			if(writer!=null)
				writer.close();
			if(out !=null)
				out.close();
		}	
	}
	
}
