package cn.edu.ustc.dehaizh.controller;

import cn.edu.ustc.dehaizh.domain.User;
import cn.edu.ustc.dehaizh.service.UserAuthenticatedService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

/**
 * Created by dehaizh on 2016/3/12.
 */

@Controller
public class LoginController {
    @Inject
    private UserAuthenticatedService userAuthenticatedService;


    @RequestMapping(value = {"/","/login"},method = RequestMethod.GET)
    public String index( Model model)
    {
        model.addAttribute("user", "dehaizh");
        return "login";

    }

    /**
     * 退出 清空session
     * @param request
     * @return
     */
    @RequestMapping(value = "/logout")
    public String toLogout(HttpServletRequest request)
    {
        request.getSession().removeAttribute("user");

        return "redirect:login";
    }

    //    @RequestMapping(value = "/toLogin",method = RequestMethod.POST )
    @RequestMapping(value = "/toLogin")
    public String toLogin(HttpServletRequest request, @Valid User user, BindingResult result, Model model)
    {
        System.out.println( "User info: "+user);
        System.out.println( "错误校验："+result.hasErrors());

        boolean validUser = userAuthenticatedService.userAuthenticate(user);
        if( !validUser )
        {
            model.addAttribute("loginError","Invalid loginName or password,Please try again!");
//            return "redirect:login";
            return  "login";
        }
        model.addAttribute("user",user);

//        保存用户信息
        HttpSession session = request.getSession();
        session.setAttribute("user",user);
        System.out.println("客户信息:"+user);
        return "home";
    }

    @RequestMapping(value = "/top",method = RequestMethod.GET)
    public String toTop(HttpServletRequest request, Model model)
    {
        HttpSession session = request.getSession();
        Object user = session.getAttribute("user");
        if(user instanceof User)
        {
            user = (User)user;
            model.addAttribute("user",user);
        }

        return  "top";
    }

    @RequestMapping(value = "/left",method = RequestMethod.GET)
    public String toLeft(HttpServletRequest request, Model model)
    {
        HttpSession session = request.getSession();
        Object user = session.getAttribute("user");
        if(user instanceof User)
        {
            user = (User)user;
            model.addAttribute("user",user);
        }

        return  "left";
    }

    @RequestMapping(value = "/main",method = RequestMethod.GET)
    public String toMain(HttpServletRequest request, Model model)
    {
        HttpSession session = request.getSession();
        Object user = session.getAttribute("user");
        if(user instanceof User)
        {
            user = (User)user;
            model.addAttribute("user",user);
        }

        return  "main";
    }

    @RequestMapping(value = "/bottom",method = RequestMethod.GET)
    public String toBottom(HttpServletRequest request, Model model)
    {
        HttpSession session = request.getSession();
        Object user = session.getAttribute("user");
        if(user instanceof User)
        {
            user = (User)user;
            model.addAttribute("user",user);
        }

        return  "bottom";
    }

    @RequestMapping(value = "/message",method = RequestMethod.GET)
    public String toMessage(HttpServletRequest request, Model model)
    {
        HttpSession session = request.getSession();
        Object user = session.getAttribute("user");
        if(user instanceof User)
        {
            user = (User)user;
            model.addAttribute("user",user);
        }

        return  "message";
    }




}
