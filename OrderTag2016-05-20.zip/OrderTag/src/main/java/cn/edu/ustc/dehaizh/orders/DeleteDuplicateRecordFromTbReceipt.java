package cn.edu.ustc.dehaizh.orders;

import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;

/**
 * Created by dehaizh on 2016/4/27.
 * 该静态类用于删除tb_receipt表中重复的记录,
 * 并且通过调用sp_delete_duplicate_from_tb_receipt()这个存储过程来实现
 * 这个存储过程主要包括如下操作：
 * 1、在tb_receipt中查找重复记录的id，并将该id写入到临时表(这是个物理表)中;
 * 2、然后删除tb_receipt中与tb_id表重相同的id
 * 以上操作在同一个事务中
 */
public class DeleteDuplicateRecordFromTbReceipt {

    private static String DELETE_DUPLICATE_FROM_RECEIPT_CALLABLE_SQL="{call sp_delete_duplicate_from_tb_receipt() }";
    public static void deleteDuplicateRecord()
    {
        System.out.printf("--------------- %20s --------------------\r\n", "正在删除tb_receipt中的重复的记录");
        DBCommonOperationWithoutJdbcDaoSupport.callNonQuery(DELETE_DUPLICATE_FROM_RECEIPT_CALLABLE_SQL, null);
    }

    public static void main(String[] args) {

        DeleteDuplicateRecordFromTbReceipt.deleteDuplicateRecord();
        System.out.println("Finished...");

    }

}
