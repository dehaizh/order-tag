package cn.edu.ustc.dehaizh.main;

import com.google.common.collect.Lists;

import java.util.ArrayList;

/**
 * Created by dehaizh on 2016/4/24.
 */
public class Main {

    public static void main(String[] args) {

        ArrayList<Integer> list = Lists.newArrayList(1, 2, 3, 4);
        System.out.println( list );

    }

}
