package cn.edu.ustc.dehaizh.csv;

import java.io.*;
import java.util.ArrayList;

public class CSVReader {

	private static final ArrayList<Object[]> EMPTY_LIST_OBJECT_ARRAY = new ArrayList<Object[]>();
	
	/**
	 * 读取指定csv文件中的数据
	 * <p>
	 * @param filename 指定的csv文件的全路径名
	 * @return 返回一个ArrayList<Object[]>类型的列表，当文件为空，返回一个空的ArrayList<Object[]>,而不是null
	 * @throws IOException 
	 */
	public static ArrayList<Object[]> read(String filename) throws IOException
	{
		ArrayList<Object[]> ret = EMPTY_LIST_OBJECT_ARRAY;
		
		File file  = new File(filename);
		InputStreamReader in = null;
		BufferedReader reader = null;
		
		in = new InputStreamReader(new FileInputStream(file), "UTF-8");
		reader = new BufferedReader(in);
		
		String line=null;
		ArrayList<Object[]> tmp = new ArrayList<Object[]>();
		while ( (line=reader.readLine() )!=null ) {
			//当引号列中含有逗号时，将保存该逗号，并将它按照一个完整的列来解析
			String[] cols = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
			for(int i=0; i<cols.length; ++i)
			{//去除字段中的双引号
				cols[i] = cols[i].replaceAll("\"", "");
			}
			tmp.add(cols);
		}
		ret = tmp;
		return ret;
	}

}
