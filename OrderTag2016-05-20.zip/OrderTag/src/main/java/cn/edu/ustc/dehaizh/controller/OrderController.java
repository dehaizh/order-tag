package cn.edu.ustc.dehaizh.controller;

import cn.edu.ustc.dehaizh.domain.HotCommodity;
import cn.edu.ustc.dehaizh.domain.ProductTrend;
import cn.edu.ustc.dehaizh.service.OrderService;
import cn.edu.ustc.dehaizh.util.CheckUtils;
import cn.edu.ustc.dehaizh.util.HotProductExcel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.util.List;

/**
 * Created by dehaizh on 2016/3/15.
 */
@Controller
public class OrderController {
    @Autowired
    private OrderService orderService;

    @RequestMapping(value = "/order/hotProduct")
    public  String finder(Model model )
    {

        return "hotProduct";
    }

    /**
     * 查询
     * @param model
     * @return
     */
    @RequestMapping(value = "/order/hotProductQuery")
    @ResponseBody
    public  String hotProductQuery(Model model, String startDate, String endDate,
                                   HttpServletRequest request,HttpServletResponse response,HttpSession session) throws IOException {
        System.out.println("进入/order/hotProductQuery");
        System.out.println("StartDate: "+startDate+" EndDate: "+endDate);
        //startDate有问题
        if(!(startDate!=null && startDate.length()>0))
        {
            startDate = "2000-01-01"; //开始时间设置为三个月前
        }else{
            startDate = convertDate2YYYYMMDD(startDate);
        }

        //endDate有问题
        if(!(endDate!=null && endDate.length()>0))
        {
            endDate = "3000-01-01"; //结束时间设置为当前时间
        }else{
            endDate = convertDate2YYYYMMDD(endDate);
        }

        System.out.println("After Process__StartDate: "+startDate+" EndDate: "+endDate);



        //结果集
//        List<Mail> mails = null;
        List<HotCommodity> hotCommodities=null;
        hotCommodities=orderService.getHotProduct(startDate,endDate);
        //所有的条件都满足

//        if(mailCategory!=null && mailCategory.length()>0 )
//        {
//            if(keyWord!=null&&keyWord.length()>0)
//                mails = mailGetService.getMailsByCategoryAndKeyWord(startDate, endDate, mailCategory, keyWord);
//            else
//                mails = mailGetService.getMailsByCategory(startDate, endDate, mailCategory);
//        }else{
//            if(keyWord!=null && keyWord.length()>0)
//                mails = mailGetService.getMailsByKeyWord(startDate,endDate, keyWord);
//            else
//                mails = mailGetService.getMailsByDate(startDate,endDate);
//        }

        StringBuilder resultBuilder = new StringBuilder();
        resultBuilder.append(" <table width='96%'>\n" +
                "            <thead>\n" +
                "            <tr>\n" +
                "                <th width='10px'>查询结果</th>\n" +
                "                <th>热门商品列表 </th>\n" +
                "            </tr>\n" +
                "            </thead>\n" +
                "            <tbody>");

        //使用getSimpleJdbcTemplate获取数据时，当数据为结果为空时，他不是返回NULL，而是返回一个长度为0的数组或者集合
        //需要特别注意

        //热门商品excel存储路径
        String filePath = session.getServletContext().getRealPath("/")+"hotproduct"+File.separator;
        File file=new File(filePath);
        if (file.exists()==false) file.mkdir();
        String filename=filePath+"hotproduct.xls";
        System.out.println("---------------filepath-------------------"+filename);

        HotProductExcel.makeOrderExcel(hotCommodities,filename);


        if(hotCommodities!=null&&hotCommodities.size()>0)
        {
//            resultBuilder.append("<tr><td colspan='2' style='color:red;'><STRONG>There are ").append(mails.size()).append(" Record(s) </STRONG>&nbsp;&nbsp;&nbsp;&nbsp; <a href='/mail-autoreply/mail/queryResult/download?startDate=").append(startDate).append("&endDate=").append(endDate).append("&mailCategory=").append(mailCategory).append("&keyWord=").append(keyWord).append("' >Download QueryResult(s)</a></td></tr>");
            resultBuilder.append("<tr><td colspan='3' style='color:red;'><STRONG>There are ").append(hotCommodities.size()).append(" Record(s)</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;").append("</td></tr>");

            //下载链接
            resultBuilder.append("<tr><td colspan='3' style='color:red;'><a href=\"download/hotproduct\">下载结果</a>").append("</td></tr>");



            for(HotCommodity hotCommodity:hotCommodities)
            {
                resultBuilder.append(" <tr>");
                resultBuilder.append("<td colspan='3' class='user-name'>\n" +
                        "                <a  class='hrefCss' href=productTrend");
                resultBuilder.append("?productname=").append(hotCommodity.getCommodity())
                .append("&&startDate=").append(startDate).append("&&endDate=")
                .append(endDate)
                .append("  target='messageFrame'  id='"+hotCommodity.getId()+"href'\n" +
                        "                    style='color:");
                resultBuilder.append("'  > ");
                resultBuilder.append(hotCommodity.getCommodity());
                resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append(hotCommodity.getCnt());
                resultBuilder.append(" </a>  </td></tr>");
            }

        }

        if(hotCommodities==null||hotCommodities.size()==0)
            resultBuilder.append("<tr><td colspan=3 style='color:red;'><STRONG>Sorry,There is no result,Please try again</STRONG></td></tr>");

        resultBuilder.append("    </tbody>\n" +
                "        </table>");

        request.setCharacterEncoding("utf-8");  //这里不设置编码会有乱码
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Cache-Control", "no-cache");
        PrintWriter out = response.getWriter();  //输出中文，这一句一定要放到response.setContentType("text/html;charset=utf-8"),  response.setHeader("Cache-Control", "no-cache")后面，否则中文返回到页面是乱码
        out.print(resultBuilder.toString());
        out.flush();
        out.close();

        return null;
    }

    @RequestMapping(value = "/order/{productId}")
    public  String yunTulabel(Model model,@PathVariable int productId)
    {
        System.out.println("进入/order/{productId}");
        System.out.println("================"+productId);
        return "productDetail";

    }

    @RequestMapping(value = "/order/productTrend")
    public  String productTrend(Model model,String productname,String startDate, String endDate) throws UnsupportedEncodingException {
        System.out.println("进入/order/{productname}");
        System.out.println("================"+productname);
        System.out.println("================"+startDate);
        System.out.println("================"+endDate);
        String encode = "ISO-8859-1";

        productname=new String(productname.getBytes(encode), "UTF-8");

        System.out.println(productname);
        List<ProductTrend>  productTrendList=orderService.hotProductTrend(startDate,endDate,productname);
        model.addAttribute("productTrendList",productTrendList);
        model.addAttribute("productname",productname);

        return "productDetail";

    }

    @RequestMapping("/order/download/{filename}")
    public void download(@PathVariable String filename, HttpServletResponse response, HttpSession session) throws IOException {
        String pdfPath = session.getServletContext().getRealPath("/")+"hotproduct"+File.separator;
        System.out.println("---------------filepath1-------------------"+pdfPath+ filename);

        filename+=".xls";
        response.setCharacterEncoding("utf-8");
        response.setContentType("multipart/form-data");
        response.setHeader("Content-Disposition", "attachment;fileName=" + filename);
        System.out.println(filename);
        try {

            InputStream inputStream = new FileInputStream(new File(pdfPath + filename));

            OutputStream os = response.getOutputStream();
            byte[] b = new byte[2048];
            int length;
            while ((length = inputStream.read(b)) > 0) {
                os.write(b, 0, length);
            }

            // 这里主要关闭。
            os.close();

            inputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String convertDate2YYYYMMDD(String startDate) {
        StringBuilder builder = new StringBuilder();
        //开始日期是 月/日/年 的形式
        String[] tmps = startDate.split("/");
        return builder.append(tmps[2]).append("-").append(tmps[0]).append("-").append(tmps[1]).toString();
    }


}
