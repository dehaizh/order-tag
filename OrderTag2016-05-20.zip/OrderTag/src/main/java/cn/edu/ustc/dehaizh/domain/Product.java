package cn.edu.ustc.dehaizh.domain;

/**
 * Created by root on 16-5-6.
 */
public class Product {
}
