package cn.edu.ustc.dehaizh.orders;

import cn.edu.ustc.dehaizh.csv.CSVReader;
import cn.edu.ustc.dehaizh.csv.CSVWriter;
import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.TanimotoCoefficientSimilarity;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by dehaizh on 2016/5/6.
 */
public class UserSimilarityCalculator {
    private static String INSERT_INTO_TB_CUSTOMER_SIMILARITY_SQL="INSERT INTO tb_customer_similarity(cId,similarityCId,similarityValue) VALUES(?,?,?)  ON DUPLICATE KEY UPDATE similarityValue=VALUES(similarityValue)";

    public static void calcSimilarity(String userCommodityFilename) throws IOException, TasteException {

        ArrayList<Object[]> userSimilarityList = new ArrayList<Object[]>();

        File dataModelFile = new File(userCommodityFilename);
        FileDataModel dataModel = new FileDataModel(dataModelFile);
        UserSimilarity similarity = new TanimotoCoefficientSimilarity(dataModel);
//         UserSimilarity similarity = new LogLikelihoodSimilarity(dataModel);

       //用户相似性阀值为0.8
        double userThreshhold=0.8;
        int nNeighbor = 6;
//        UserNeighborhood neighborhood = new ThresholdUserNeighborhood(userThreshhold, similarity, dataModel);
        UserNeighborhood neighborhood = new NearestNUserNeighborhood(nNeighbor, similarity, dataModel);

        GenericUserBasedRecommender recommender = new GenericUserBasedRecommender(dataModel, neighborhood, similarity);

        int numOfRecommendedUser=6;
        int numOfRecommendedItem = 2;

        //计算每个用户的 neighborhood
        LongPrimitiveIterator userIDs = dataModel.getUserIDs();
        while (userIDs.hasNext())
        {
            long currUserId = userIDs.nextLong();
            long[] similarUserIDs = recommender.mostSimilarUserIDs(currUserId, numOfRecommendedUser);
//            System.out.println("CustomerId:"+currUserId+" 与该客户相似的客户id列表为:"+Arrays.toString(similarUserIDs));
//            List<RecommendedItem> items = recommender.recommend(i, numOfRecommendedItem);
//            for(RecommendedItem elem:items)
//            {
//                System.out.printf("      --------推荐物品id为 %4d------\r\n",elem.getItemID());
//            }
            for(long userId:similarUserIDs)
            {
//                System.out.printf("      ----------客户%4d与客户%4d的相似度为%6.2f----------\r\n", currUserId, userId, similarity.userSimilarity(currUserId, userId));
                Object[] record = new Object[3];
                record[0] = currUserId;
                record[1] = userId;
                record[2] = (int)(similarity.userSimilarity(currUserId,userId)*100);
                userSimilarityList.add(record);
            }

        }

        System.out.println("正在将数据dump到数据库中");
        if (userSimilarityList.size()>0)
            DBCommonOperationWithoutJdbcDaoSupport.batch(INSERT_INTO_TB_CUSTOMER_SIMILARITY_SQL, userSimilarityList);

        //测试用户的 相似度
//        for(int i=1;i<10;++i) {
//            long[] similarUserIDs = recommender.mostSimilarUserIDs(i, numOfRecommendedUser);
//            System.out.println("CustomerId:"+i+" 与该客户相似的客户id列表为:"+Arrays.toString(similarUserIDs));
////            List<RecommendedItem> items = recommender.recommend(i, numOfRecommendedItem);
////            for(RecommendedItem elem:items)
////            {
////                System.out.printf("      --------推荐物品id为 %4d------\r\n",elem.getItemID());
////            }
//            for(long userId:similarUserIDs)
//            {
//                System.out.printf("      ----------客户%4d与客户%4d的相似度为%6.2f----------\r\n", i, userId, similarity.userSimilarity(i, userId));
//            }
//
//        }

//        System.out.println("1号客户与4658号客户的相似度为_" + similarity.userSimilarity(1, 619));
//        System.out.println("1号客户与4658号客户的相似度为_" + similarity.userSimilarity(619, 1));

//        LongPrimitiveIterator userIDs = dataModel.getUserIDs();
//        while (userIDs.hasNext())
//        {
//            System.out.print(userIDs.nextLong()+",");
//        }

    }

    private static void makeCSVFile(String originalFile,String destFile ) throws IOException {
        ArrayList<Object[]> list = CSVReader.read(originalFile);

        ArrayList<Object[]> result = new ArrayList<Object[]>(list.size());

        for(Object[] record:list)
        {
            int userId = Integer.parseInt(record[0].toString());
            String[] commodityIds = record[1].toString().split(",");
//            String commodityIds = record[1].toString();
            for(String commodityId:commodityIds)
            {
                Object[] ret = new Object[2];
                ret[0] = userId;
                ret[1] = commodityId;
                result.add(ret);
            }

        }

        if(result.size()>0)
        {
            CSVWriter.saveArrayObject(result,destFile);
        }

    }

    public static void main(String[] args) throws IOException, TasteException {

        String originalFile = "D:/userCommodity.csv";
        String destFile = "D:/userCommodityIds.csv";
        UserSimilarityCalculator.makeCSVFile(originalFile, destFile);

        UserSimilarityCalculator.calcSimilarity(destFile);

    }

}
