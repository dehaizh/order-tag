package cn.edu.ustc.dehaizh.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * 
 * @author dehaizh
 *
 *使用c3p0数据库连接池来管理数据连接
 *
 */
public final class DBConnection {
	
	private static final DataSource ds;
	
	static{
		//选择数据库类型 
		//mysql dbwmordertag
		ds = new ComboPooledDataSource("dbwmordertag");
	}
	
	//私有构造器来增强该类不可实例化的能力
	private DBConnection(){ throw new AssertionError("不允许创建数据库连接对象实例");}
	
	//返回c3p0实现的DataSource对象
	public static DataSource getDataSource()
	{
		return ds;
	}
	
	/*
	 * @return 返回java.sql.Connection对象
	 */
	public static Connection getDBConnection()
	{
		Connection connection = null;
		try {
			connection = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}
	
	public static void main(String[] args)
	{	
		System.err.println("Connection: "+DBConnection.getDBConnection());
	
	}
	
}
