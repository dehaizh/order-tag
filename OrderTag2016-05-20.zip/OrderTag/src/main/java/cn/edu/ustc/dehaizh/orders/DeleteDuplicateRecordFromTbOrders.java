package cn.edu.ustc.dehaizh.orders;

import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;


/**
 * Created by dehaizh on 2016/4/27.
 */
public class DeleteDuplicateRecordFromTbOrders {

    private static String DELETE_DUPLICATE_FROM_TB_ORDERS_CALLABLE_SQL="{call sp_delete_duplicate_from_tb_orders()}";

    public static void deleteDuplicateRecord()
    {

        System.out.printf("--------------- %20s --------------------\r\n", "正在删除tb_orders中的重复的记录");
        DBCommonOperationWithoutJdbcDaoSupport.callNonQuery(DELETE_DUPLICATE_FROM_TB_ORDERS_CALLABLE_SQL, null);

    }

    public static void main(String[] args) {

        DeleteDuplicateRecordFromTbOrders.deleteDuplicateRecord();
        System.out.println("Finished...");
    }

}
