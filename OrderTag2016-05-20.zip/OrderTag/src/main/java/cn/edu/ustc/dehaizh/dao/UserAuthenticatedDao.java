package cn.edu.ustc.dehaizh.dao;

import cn.edu.ustc.dehaizh.domain.User;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import java.util.List;
import java.util.Map;

/**
 * Created by dehaizh on 2016/3/30.
 */
public class UserAuthenticatedDao extends SimpleJdbcDaoSupport{

    public boolean authenticate(User user)
    {
        //SELECT * FROM tb_user WHERE loginName = 'dehaizh' AND loginPassword = 'dehaizh';
        String sql = "SELECT * FROM tb_user WHERE loginName = ? AND loginPassword = ? ";
        List<Map<String, Object>> list = getSimpleJdbcTemplate().queryForList(sql, user.getUsername(), user.getPassword());

        if(list.size()>0) {
            int validUser = Integer.parseInt( list.get(0).get("validUser").toString());
            if (validUser==1)
                return true;
        }
        return false;
    }

}
