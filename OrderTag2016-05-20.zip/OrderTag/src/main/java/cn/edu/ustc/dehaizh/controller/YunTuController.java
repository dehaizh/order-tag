package cn.edu.ustc.dehaizh.controller;

import cn.edu.ustc.dehaizh.domain.BuyRecord;
import cn.edu.ustc.dehaizh.domain.Customer;
import cn.edu.ustc.dehaizh.domain.LabelDetail;
import cn.edu.ustc.dehaizh.service.OrderService;
import cn.edu.ustc.dehaizh.service.YunTuService;
import cn.edu.ustc.dehaizh.util.CheckUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 * Created by dehaizh on 2016/3/15.
 */
@Controller
public class YunTuController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private YunTuService yunTuService;

    @RequestMapping(value = "/yuntu/toYunTu")
    public  String yuntu(Model model )
    {
        System.out.println("/yuntu/toYunTu");

        List<String> ageCategory =yunTuService.getAgeCategory();
        List<String>tageCategory=yunTuService.getTageCategory();

        model.addAttribute("ageCategory",ageCategory);
        model.addAttribute("tageCategory",tageCategory);
        return "yuntu";
    }

    /**
     * 查询
     * @param model
     * @return
     */
    @RequestMapping(value = "/yuntu/yunTuQuery")
    @ResponseBody
    public  String hotProductQuery(Model model, String startDate, String endDate,
                                   String ageCategory, String areaCategory,
                                   String tageCategory, String sex,
                                   HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("----------------");
        System.out.println("进入/yuntu/yunTuQuery");
        System.out.println("startDate: " +startDate+" endDate: "+endDate+" ageCategory: "+ageCategory
        +" areaCategory: "+areaCategory+" sex: "+sex+" tageCategory: "+tageCategory);

        if (CheckUtils.isNull(startDate)){startDate=null;}
        if (CheckUtils.isNull(endDate)){endDate=null;}
        if (CheckUtils.isNull(ageCategory)){ ageCategory=null;}
        if (CheckUtils.isNull(areaCategory)||areaCategory.trim().equals("请选择市区")){areaCategory=null;}
        if (CheckUtils.isNull(tageCategory)){tageCategory=null; }
        if (CheckUtils.isNull(sex)){sex=null;}
        System.out.println("startDate: " +startDate+" endDate: "+endDate+" ageCategory: "+ageCategory
                +" areaCategory: "+areaCategory+" sex: "+sex+" tageCategory: "+tageCategory);


        List<LabelDetail> labelDetailList=yunTuService.fetchLabelDetail(startDate,endDate,ageCategory,areaCategory,tageCategory,sex);

        StringBuffer resultBuilder = new StringBuffer();
        resultBuilder.append(" <table width='96%'>\n" +
                "            <thead>\n" +
                "            <tr>\n" +
                "                <th width='10px'>Box</th>\n" +
                "                <th>Hot Products List </th>\n" +
                "            </tr>\n" +
                "            </thead>\n" +
                "            <tbody>");

        if(labelDetailList!=null&&labelDetailList.size()>0)
        {
//             resultBuilder.append("<tr><td colspan='2' style='color:red;'><STRONG>There are ").append(mails.size()).append(" Record(s) </STRONG>&nbsp;&nbsp;&nbsp;&nbsp; <a href='/mail-autoreply/mail/queryResult/download?startDate=").append(startDate).append("&endDate=").append(endDate).append("&mailCategory=").append(mailCategory).append("&keyWord=").append(keyWord).append("' >Download QueryResult(s)</a></td></tr>");
            resultBuilder.append("<tr><td colspan='3' style='color:red;'><STRONG>There are ").append(labelDetailList.size()).append(" Record(s)</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;").append("</td></tr>");


            for(LabelDetail labelDetail:labelDetailList)
            {
                resultBuilder.append(" <tr> ");
                resultBuilder.append("<td class='user-name'>").append(labelDetail.getCustomerId()).append("</td>\n");



                resultBuilder.append("<td class='user-name'>" +
                        "                <a  class='hrefCss' href='yunLabel/").append(labelDetail.getCustomerId()).
                        append("' target='messageFrame'  id='"+labelDetail.getCustomerId()+"href'\n" );
                resultBuilder.append("> ");
                resultBuilder.append(labelDetail.getcName());resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append(labelDetail.getLabelDetail()); resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append(labelDetail.getcAddress()); resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append(labelDetail.getcAge()); resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append(labelDetail.getcGender()); resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append(labelDetail.getcIdNo()); resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append(labelDetail.getcPhone()); resultBuilder.append(" &nbsp;&nbsp; ");

                resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append((double)labelDetail.getcTotalSum()/100);
                resultBuilder.append(" </a>  </td></tr>\n");

            }

        }

        if(labelDetailList==null||labelDetailList.size()==0)
            resultBuilder.append("<tr><td colspan=3 style='color:red;'><STRONG>很抱歉，尚未查找到适合的条件</STRONG></td></tr>");

        resultBuilder.append("    </tbody>\n" +
                "        </table>");

        request.setCharacterEncoding("utf-8");  //这里不设置编码会有乱码
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Cache-Control", "no-cache");
        PrintWriter out = response.getWriter();  //输出中文，这一句一定要放到response.setContentType("text/html;charset=utf-8"),  response.setHeader("Cache-Control", "no-cache")后面，否则中文返回到页面是乱码
        out.print(resultBuilder.toString());
        out.flush();
        out.close();

        return null;


    }
    @RequestMapping(value = "/yuntu/yunLabel/{customId}")
    public  String yunTulabel(Model model,@PathVariable int customId)
    {
        System.out.println("进入/yuntu/{labelId}");

        LabelDetail labelDetail=yunTuService.fetchLabelDetail(customId);
        List<BuyRecord> buyRecordList=orderService.fetchBuyRecordsWithoutRepeat(labelDetail.getcPhone());
        String customCommunity=orderService.fetchSimilarCustomer(labelDetail.getcPhone());
        List<Customer> customerList=orderService.fetchSimilarCustomer(customId);

        model.addAttribute("customerList",customerList);
        model.addAttribute("labelDetail",labelDetail);
        model.addAttribute("buyRecordList",buyRecordList);
        model.addAttribute("customCommunity",customCommunity);
        System.out.println("================"+customId);

        String[] relation = customCommunity.split(",");
        model.addAttribute("relation",relation);

        String[] category= labelDetail.getLabelDetail().split(",");
        model.addAttribute("category",category);


        return "yunLabel";

    }


    @RequestMapping(value = "/yuntu/yunLabel/fetchDetail")
    public  String recordsDetail(Model model,HttpServletRequest request) throws UnsupportedEncodingException {
        System.out.println("进入/yuntu/yunLabel/{commodityDescription}_{phoneNumber}");

        request.setCharacterEncoding("utf-8");
        String commodityDescription=request.getParameter("commodityDescription");
        String phoneNumber=request.getParameter("phoneNumber");

        System.out.println("================"+commodityDescription+" "+phoneNumber);

        String encode = "ISO-8859-1";

        commodityDescription=new String(commodityDescription.getBytes(encode), "UTF-8");

        System.out.println(commodityDescription);




        List<BuyRecord> buyRecordList=orderService.fetchBuyRecordDetail(commodityDescription,phoneNumber);


        model.addAttribute("buyRecordList",buyRecordList);
        System.out.println("================"+commodityDescription+" "+phoneNumber);



        return "buyDetail";

    }


    @RequestMapping(value = "/yuntu/force")
    public  String forcelabel(Model model)
    {
        System.out.println("进入/yuntu/force");


        return "force";

    }

    public static String getEncoding(String str) {
        String encode = "GB2312";
        try {
            if (str.equals(new String(str.getBytes(encode), encode))) { //判断是不是GB2312
                String s = encode;
                return s; //是的话，返回“GB2312“，以下代码同理
            }
        } catch (Exception exception) {
        }
        encode = "ISO-8859-1";
        try {
            if (str.equals(new String(str.getBytes(encode), encode))) { //判断是不是ISO-8859-1
                String s1 = encode;
                return s1;
            }
        } catch (Exception exception1) {
        }
        encode = "UTF-8";
        try {
            if (str.equals(new String(str.getBytes(encode), encode))) { //判断是不是UTF-8
                String s2 = encode;
                return s2;
            }
        } catch (Exception exception2) {
        }
        encode = "GBK";
        try {
            if (str.equals(new String(str.getBytes(encode), encode))) { //判断是不是GBK
                String s3 = encode;
                return s3;
            }
        } catch (Exception exception3) {
        }
        return ""; //如果都不是，说明输入的内容不属于常见的编码格式。
    }
}
