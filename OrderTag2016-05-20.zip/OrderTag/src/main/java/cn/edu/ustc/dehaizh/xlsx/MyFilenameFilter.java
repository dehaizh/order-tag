package cn.edu.ustc.dehaizh.xlsx;

import java.io.File;
import java.io.FilenameFilter;

public class MyFilenameFilter implements FilenameFilter{

	private static String Filename_Extension; 
	
	public MyFilenameFilter(String extension)
	{
		Filename_Extension = extension.trim();
	}

	public boolean accept(File dir, String name) {
		// TODO Auto-generated method stub
		//如果是*通配符，则返回该目录下的所有文件
		//System.err.println(MyFilenameFilter.class+"filename: "+name);
		if("*".equals(Filename_Extension))
			return true;
		else return name.endsWith(Filename_Extension);
	}

}
