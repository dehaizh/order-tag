package cn.edu.ustc.dehaizh.util;

import java.util.List;
import java.util.Map;

/**
 * Created by dehaizh on 2016/3/17.
 */
public interface IDBCommonOperation {

    /**
     * execute for update,insert,delete that without rerurns
     * @param sql
     * @param params NamedParametered HashMap,such as:
     *              sql = INSERT INTO tb_mail(sentDate,mailSubject) VALUES(:sentDate,:mailSubject)
     *               then map should be map.put("sentDate","2015-03-16-20-08-39"); map.put("mailSubject","hello");
     */
    void executeNonQuery(String sql, Map params);

    /**
     * execute for select that with returns
     * @param sql
     * @param params it is also NamedParametered HashMap
     * @return
     */
    List executeQuery(String sql, Map params);

    /**
     * batch operation,such as dumping the csv file into db
     * @param sql
     * @param params
     */
    int[] batch(String sql, List<Object[]> params);
}
