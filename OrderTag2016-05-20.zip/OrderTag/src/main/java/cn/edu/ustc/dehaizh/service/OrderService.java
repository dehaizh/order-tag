package cn.edu.ustc.dehaizh.service;

import cn.edu.ustc.dehaizh.domain.BuyRecord;
import cn.edu.ustc.dehaizh.domain.Customer;
import cn.edu.ustc.dehaizh.domain.HotCommodity;
import cn.edu.ustc.dehaizh.domain.ProductTrend;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;

/**
 * Created by root on 16-5-5.
 */

public interface OrderService {
    public List<HotCommodity> getHotProducts();
    public List<HotCommodity> getHotProducts(Date beginDate, Date endDate);
    public List<BuyRecord> fetchBuyRecords(String phoneNumber);
    public String fetchSimilarCustomer(String phoneNumber);
    public List<Customer> fetchSimilarCustomer(Integer customId);
    public List<BuyRecord> fetchBuyRecordsWithoutRepeat(String phoneNumber);
    public List<BuyRecord> fetchBuyRecordDetail(String commodityDescription, String phoneNumber);
    public List<HotCommodity> getHotProduct(String beginDate,String endDate);
    public  List<ProductTrend>  hotProductTrend(String beginDate, String endDate, String commodityDescription) throws UnsupportedEncodingException;
}
