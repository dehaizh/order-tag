package cn.edu.ustc.dehaizh.orders;

/**
 * Created by dehaizh on 2016/4/22.
 */
public interface IStrategy {
    void execute();
}
