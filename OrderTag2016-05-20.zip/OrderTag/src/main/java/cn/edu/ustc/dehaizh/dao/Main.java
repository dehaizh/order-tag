package cn.edu.ustc.dehaizh.dao;


import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by dehaizh on 2016/4/24.
 */
public class Main {

    /**
     * 从开始时间到结束时间热门商品 例子
     */
    public static void getHotProduct()
    {
        String procName = "{call sp_select_hot_product_from_tb_receipt(?,?) }";
        //参数为开始日期和结束日期
        //日期格式为YYYY-MM-DD
        ArrayList<Object> params = new ArrayList<Object>();
        params.add("2016-01-01");
        params.add("2016-05-10");

        //返回值的每条记录为 商品名称和销售数量
        ArrayList<Object[]> result = DBCommonOperationWithoutJdbcDaoSupport.callQuery(procName, params);
        for(Object[] record:result)
        {
            System.out.println(Arrays.toString(record));
        }

    }

    /**
     * 获取指定商品在指定时间段内的每个月的销售量
     */
    public static void hotProductTrend() throws UnsupportedEncodingException {
        String procName = "{call sp_select_hot_product_trend(?,?,?) }";
        //参数为开始日期、结束日期和商品名称
        //日期格式为YYYY-MM-DD
        ArrayList<Object> params = new ArrayList<Object>();
        params.add("2016-01-01");
        params.add("2016-05-10");


        String commodityDescription="鞋";
        System.out.println(commodityDescription);

        String encode = "GB2312";

        commodityDescription=new String(commodityDescription.getBytes(encode), "GB2312");

        System.out.println(commodityDescription);

        params.add(commodityDescription);


        //返回值的每一行记录为 日期和该商品在该月中的销售数量
        ArrayList<Object[]> result = DBCommonOperationWithoutJdbcDaoSupport.callQuery(procName, params);
        for(Object[] record:result)
        {
            System.out.println(Arrays.toString(record));
        }

    }
    public static String getEncoding(String str) {
        String encode = "GB2312";
        try {
            if (str.equals(new String(str.getBytes(encode), encode))) { //判断是不是GB2312
                String s = encode;
                return s; //是的话，返回“GB2312“，以下代码同理
            }
        } catch (Exception exception) {
        }
        encode = "ISO-8859-1";
        try {
            if (str.equals(new String(str.getBytes(encode), encode))) { //判断是不是ISO-8859-1
                String s1 = encode;
                return s1;
            }
        } catch (Exception exception1) {
        }
        encode = "UTF-8";
        try {
            if (str.equals(new String(str.getBytes(encode), encode))) { //判断是不是UTF-8
                String s2 = encode;
                return s2;
            }
        } catch (Exception exception2) {
        }
        encode = "GBK";
        try {
            if (str.equals(new String(str.getBytes(encode), encode))) { //判断是不是GBK
                String s3 = encode;
                return s3;
            }
        } catch (Exception exception3) {
        }
        return ""; //如果都不是，说明输入的内容不属于常见的编码格式。
    }

    public static void main(String[] args) {

        //获取热门商品例子
//        getHotProduct();

        System.out.println(getEncoding("鞋子"));
        //热门商品每月销售量例子
       getHotProduct();

    }

}
