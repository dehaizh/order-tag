package cn.edu.ustc.dehaizh.domain;

/**
 * 根据数据库中 tb_commodity_2_id相应字段做出的对应热门商品
 * Created by root on 16-5-6.
 */
public class HotCommodity {
    private Integer id;
    private String commodity;
    private Integer cnt;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCommodity() {
        return commodity;
    }

    public void setCommodity(String commodity) {
        this.commodity = commodity;
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }
}
