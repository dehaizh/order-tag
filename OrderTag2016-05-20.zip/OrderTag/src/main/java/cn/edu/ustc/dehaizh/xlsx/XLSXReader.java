package cn.edu.ustc.dehaizh.xlsx;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/**
 * Excel存储日期、时间均以数值类型进行存储，读取时POI先判断是否是数值类型，
 * 若是，则再判断是纯数值类型，还是日期时间数值类型;根据excel文件名来读取该文件中的sheet表中信息
 * 并且每个表都返回一个ArrayList<ArrayList<String>>类型的列表,当sheet为空时，则返回一个空的列表类型
 * 而不是null类型
 * @author dehaizh
 *
 */
public class XLSXReader {
	//长度为零的常量ArrayList集合
	private static ArrayList<ArrayList<String>> EMPTY_ARRAYLIST = new ArrayList<ArrayList<String>>();
	
	private String filename;		//Excel文件名
	private final  int numOfSheets;	//Excel文件中sheet的数目
	private Workbook workbook;		//
	
	/**
	 * 
	 * @param filename Excel文件绝对路径名
	 * @throws IOException	不是合法的文件名
	 */
	public XLSXReader(String filename) throws IOException
	{
		File file = new File(filename);
		if(!file.exists())
			throw new IOException("Invalid Filename:"+filename);
		
		this.filename = filename;
		InputStream in = new FileInputStream(filename);
		
		if(filename.endsWith("xls"))	//是xls,则创建HSSFWorkbook
			this.workbook = new HSSFWorkbook(in);
		else if(filename.endsWith("xlsx"))//是xlsx,则创建XSSFWorkbook
			this.workbook = new XSSFWorkbook(in);
		this.numOfSheets = workbook.getNumberOfSheets();	
	}
	
	/**
	 * 
	 * @param sheetIndex Excel文件中sheet的序号
	 * @return	返回该sheet中所有的数据，以二维表(ArrayList<ArrayList<String>>)的形式来表示
	 * 如果没有数据，则返回一个空的ArrayList集合
	 */
	public ArrayList<ArrayList<String>> readExcelSheet(int sheetIndex)
	{
		//EMPTY_ARRAYLIST.clear();
		ArrayList<ArrayList<String>> resultList = new ArrayList<ArrayList<String>>();
		org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(sheetIndex);
		Row row = null;
		Cell cell = null;
		String cellStr ="";
		for(int i=sheet.getFirstRowNum(); i<=sheet.getLastRowNum(); ++i) 
		//for (int i = sheet.getFirstRowNum(); i < sheet.getPhysicalNumberOfRows(); i++)
	        {
			 	ArrayList<String> rowList = new ArrayList<String>();
	        	row = sheet.getRow(i);
	        	if(row!=null)
	        	{
	        		 for (int j = row.getFirstCellNum(); j <= row.getLastCellNum(); j++)
	 	            {
	 	                // 通过 row.getCell(j).toString() 获取单元格内容，
	 	            	cell  = row.getCell(j);
	 	            	cellStr = "";
	 	                cellStr = parseExcel(cell);
	 	               // System.err.print(cellStr + "\t\t\t");
	 	                rowList.add(cellStr);
	 	            }
	 	            resultList.add(rowList);
	 	            
	        	}
	           
	            //System.err.println();
	        }
		return resultList;
	}
	/**
	 * 解析Excel文件单元里的内容，因为Excel文件中日期、时间都是采用数值格式
	 * 要通过数值类型来解析数值格式
	 * @param cell	Excel单元格对象
	 * @return	日期、时间、数值、字符串的字符串类型
	 */
	private String parseExcel(Cell cell) {
		String result = "";
		if(cell==null)
			return result;
		
		switch (cell.getCellType()) {
		case HSSFCell.CELL_TYPE_NUMERIC:// 数字类型
			if (HSSFDateUtil.isCellDateFormatted(cell)) {// 处理日期格式、时间格式
				SimpleDateFormat sdf = null;
				if (cell.getCellStyle().getDataFormat() == HSSFDataFormat
						.getBuiltinFormat("h:mm")) {
					sdf = new SimpleDateFormat("HH:mm");
				} else {// 日期
					sdf = new SimpleDateFormat("yyyy-MM-dd");
				}
				Date date = cell.getDateCellValue();
				result = sdf.format(date);
			} else if (cell.getCellStyle().getDataFormat() == 58 || cell.getCellStyle().getDataFormat() == 28) {
				// 处理自定义日期格式：m月d日(通过判断单元格的格式id解决，id的值是58)
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				double value = cell.getNumericCellValue();
				Date date = org.apache.poi.ss.usermodel.DateUtil
						.getJavaDate(value);
				result = sdf.format(date);
			} else {
				double value = cell.getNumericCellValue();
				CellStyle style = cell.getCellStyle();
				//DecimalFormat format = new DecimalFormat();
				DecimalFormat format = new DecimalFormat();
				String temp = style.getDataFormatString();
				// 单元格设置成常规
				if (temp.equals("General")) {
					format.applyPattern("####.####");
				}
				else {
					format.applyPattern("###.########");
				}
				result = format.format(value);
				//double value = cell.getNumericCellValue();
				//result = String.valueOf(value);
			}
			break;
		case HSSFCell.CELL_TYPE_STRING:// String类型
			result = cell.getRichStringCellValue().toString();
			break;
		case HSSFCell.CELL_TYPE_BLANK:
			result = "";
		default:
			result = "";
			break;
		}
		return result;
	}

	/**
	 * @return the numOfSheets
	 */
	public int getNumOfSheets() {
		return numOfSheets;
	}

	/**
	 * XLSXReader使用
	 * 
	 */
	public static void main(String[] args) throws IOException {
		String filename = "C:\\FileProcess\\OrderCheckExcelEMS\\OrderExcelEMS\\";
		XLSXReader reader = new XLSXReader(filename);
		int numOfSheets = reader.getNumOfSheets();
		ArrayList<ArrayList<String>> table = new ArrayList<ArrayList<String>>();
		
		for(int i=0; i<numOfSheets; ++i)
		{
			table = reader.readExcelSheet(i);
			if(table.size()>0)
			{

			}
			
		}
		System.err.println("Finished");
	}
	
}
