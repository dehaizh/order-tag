package cn.edu.ustc.dehaizh.domain;

import javax.validation.constraints.Size;

/**
 * Created by dehaizh on 2016/3/15.
 */
public class User {
    @Size(min = 3,max = 15,message = "username should be alphanum between 3 and 15")
    private String username;
    @Size(min = 3,max = 15)
    private String password;
    private int testUser;
    private int validUser;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User() {
    }

    public int getValidUser() {
        return validUser;
    }

    public void setValidUser(int validUser) {
        this.validUser = validUser;
    }

    public int getTestUser() {
        return testUser;
    }

    public void setTestUser(int testUser) {
        this.testUser = testUser;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", testUser=" + testUser +
                ", validUser=" + validUser +
                '}';
    }
}
