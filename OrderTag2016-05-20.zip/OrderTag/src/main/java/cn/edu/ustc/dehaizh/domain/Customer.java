package cn.edu.ustc.dehaizh.domain;

/**
 * Created by root on 16-5-10.
 */
public class Customer {
    private Integer id;
    private String cName;
    private Integer cAge;
    private Integer cGender;
    private String cIdNo;
    private String cProvince;
    private String cCity;
    private String cDistrict;
    private String cAddress;
    private String cPhone;
    private Integer cTotalSum;

    private Integer similarityValue;

    public Integer getSimilarityValue() {
        return similarityValue;
    }

    public void setSimilarityValue(Integer similarityValue) {
        this.similarityValue = similarityValue;
    }

    public Customer() {
    }

    public Customer(Integer id, String cName, Integer cAge, Integer cGender, String cIdNo, String cProvince, String cCity, String cDistrict, String cAddress, String cPhone, Integer cTotalSum, Integer similarityValue) {
        this.id = id;
        this.cName = cName;
        this.cAge = cAge;
        this.cGender = cGender;
        this.cIdNo = cIdNo;
        this.cProvince = cProvince;
        this.cCity = cCity;
        this.cDistrict = cDistrict;
        this.cAddress = cAddress;
        this.cPhone = cPhone;
        this.cTotalSum = cTotalSum;
        this.similarityValue = similarityValue;
    }

    public Customer(Integer id, String cName, Integer cAge, Integer cGender, String cIdNo, String cProvince, String cCity, String cDistrict, String cAddress, String cPhone, Integer cTotalSum) {
        this.id = id;
        this.cName = cName;
        this.cAge = cAge;
        this.cGender = cGender;
        this.cIdNo = cIdNo;
        this.cProvince = cProvince;
        this.cCity = cCity;
        this.cDistrict = cDistrict;
        this.cAddress = cAddress;
        this.cPhone = cPhone;
        this.cTotalSum = cTotalSum;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public Integer getcAge() {
        return cAge;
    }

    public void setcAge(Integer cAge) {
        this.cAge = cAge;
    }

    public Integer getcGender() {
        return cGender;
    }

    public void setcGender(Integer cGender) {
        this.cGender = cGender;
    }

    public String getcIdNo() {
        return cIdNo;
    }

    public void setcIdNo(String cIdNo) {
        this.cIdNo = cIdNo;
    }

    public String getcProvince() {
        return cProvince;
    }

    public void setcProvince(String cProvince) {
        this.cProvince = cProvince;
    }

    public String getcCity() {
        return cCity;
    }

    public void setcCity(String cCity) {
        this.cCity = cCity;
    }

    public String getcDistrict() {
        return cDistrict;
    }

    public void setcDistrict(String cDistrict) {
        this.cDistrict = cDistrict;
    }

    public String getcAddress() {
        return cAddress;
    }

    public void setcAddress(String cAddress) {
        this.cAddress = cAddress;
    }

    public String getcPhone() {
        return cPhone;
    }

    public void setcPhone(String cPhone) {
        this.cPhone = cPhone;
    }

    public Integer getcTotalSum() {
        return cTotalSum;
    }

    public void setcTotalSum(Integer cTotalSum) {
        this.cTotalSum = cTotalSum;
    }
}
