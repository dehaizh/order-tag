package cn.edu.ustc.dehaizh.xlsx;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class XLSXWriter {

	/**
	 * 
	 * @param dest	生成的Excel文件的绝对路径和
	 * @return		WorkBook对象
	 * @throws IOException 如果后缀名不合法，不是xls、或者xlsx，则抛出异常
	 */
	private static Workbook getWorkbook(String dest) throws IOException
	{
		Workbook workbook = null;
		if(dest.endsWith("xlsx"))
			workbook = new XSSFWorkbook();
		else if(dest.endsWith("xls"))
			workbook = new HSSFWorkbook();
		else 	//不合法的后缀名
			throw new IOException("Invalid File Extension "+dest);
		return workbook;
	}//end of function getWorkbook()
	
	
	/**
	 * 
	 * @param list 参数为ArrayList<Object[]>类型的列表，每一个Object[]表示一行记录
	 * @param dest	表示该Excel文件需要存储的路径
	 * @throws IOException 如果文件类型不是xls、xlsx,则抛出类型错误异常
	 * @category 该函数用来将ArrayList<Object[]>中的数据存储到Excel文件中
	 */
	public static void save(ArrayList<Object[]> list, String dest) throws IOException
	{
		Workbook workbook = null;
		workbook = getWorkbook(dest);
		if(workbook!=null)
		{
			Sheet sheet = workbook.createSheet("Sheet1");
			int rownum = 0;		//行号
			for(Object[] rowList :list)
			{//将table中数据写入sheet中
				Row row = sheet.createRow(rownum++);
				int column = 0;	//列号
				for(Object element :rowList)
				{
					Cell cell = row.createCell(column++);
					cell.setCellValue(element.toString());
				}
			}
			OutputStream out = new FileOutputStream(dest);
			try {
				workbook.write(out);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{//关闭文件流
				if(out !=null)
					try {
						out.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
		}
		
	}// end of function save()
	
	
	/**
	 * 
	 * @param table	table是ArrayList<ArrayList<String>>类型的列表
	 * @param dest	dest表示Excel文件存储的路径
	 * @throws IOException	如果文件名不是 xls、xlsx，则抛出文件类型错误异常
	 * @category 该函数用来将数据存储到Excel文件中 数据存储方式为ArrayList<ArrayList<String>>类型
	 */
	public static void saveExcel(ArrayList<ArrayList<String>> table, String dest) throws IOException
	{
		
		Workbook workbook = null;
		workbook = getWorkbook(dest);
		Sheet sheet = workbook.createSheet("Sheet1");
		
		int rownum = 0;		//行号
		for(ArrayList<String> rowList :table)
		{//将table中数据写入sheet中
			Row row = sheet.createRow(rownum++);
			int column = 0;	//列号
			for(String element :rowList)
			{
				Cell cell = row.createCell(column++);
				cell.setCellValue(element);
			}
		}
		OutputStream out = new FileOutputStream(dest);
		try {
			workbook.write(out);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{//关闭文件流
			if(out !=null)
				try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}// end of saveExcel function
	
}
