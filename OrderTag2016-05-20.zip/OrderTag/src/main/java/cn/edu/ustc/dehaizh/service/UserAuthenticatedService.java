package cn.edu.ustc.dehaizh.service;

import cn.edu.ustc.dehaizh.dao.UserAuthenticatedDao;
import cn.edu.ustc.dehaizh.domain.User;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * Created by dehaizh on 2016/3/30.
 */
@Service
public class UserAuthenticatedService {

    @Inject
    @Named("userAuthenticatedDao")
    private UserAuthenticatedDao userAuthenticatedDao;

    /**
     * 校验该用户是否是合法的用户
     * @param user
     * @return
     */
    public boolean userAuthenticate(User user)
    {
        return  userAuthenticatedDao.authenticate(user);
    }

}
