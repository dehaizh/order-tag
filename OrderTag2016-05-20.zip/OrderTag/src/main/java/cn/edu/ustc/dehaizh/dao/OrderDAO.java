package cn.edu.ustc.dehaizh.dao;

import cn.edu.ustc.dehaizh.domain.BuyRecord;
import cn.edu.ustc.dehaizh.domain.Customer;
import cn.edu.ustc.dehaizh.domain.HotCommodity;
import cn.edu.ustc.dehaizh.domain.ProductTrend;
import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * Created by root on 16-5-5.
 */
@Repository("orderDAO")
public class OrderDAO {
    /**
     * 查找热门商品
     * @return
     */
    public List<HotCommodity> getHotProducts(){
        List<HotCommodity> products=new LinkedList<HotCommodity>();
        String sql="select *  from tb_commodity_2_id limit 0,1000";
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        for (Object[] objects:result) {
            HotCommodity hot=new HotCommodity();
            hot.setId(Integer.parseInt(objects[0].toString()));
            hot.setCommodity((String)objects[1]);
            hot.setCnt(Integer.parseInt(objects[2].toString()));
            products.add(hot);
//            for (int i = 0; i < objects.length; i++) {
//                System.out.println("-------------------------------");
//                System.out.println(objects[i]);
//            }
        }
        return  products;
    }

    /**
     * 从开始时间到结束时间热门商品 例子
     */
    public List<HotCommodity> getHotProduct(String beginDate,String endDate)
    {
//        String procName = "{call sp_select_hot_product_from_tb_receipt(?,?) }";
        //参数为开始日期和结束日期
        //日期格式为YYYY-MM-DD
        String sql = "SELECT commodityDescription,SUM(cnt) cnt FROM tb_receipt " +
                "WHERE reviewDateTime>=? AND reviewDateTime<=? " +
                "GROUP BY commodityDescription " +
                "ORDER BY cnt DESC " +
                "LIMIT 3000;";
        ArrayList<Object> params = new ArrayList<Object>();
        params.add(beginDate);
        params.add(endDate);

        //返回值的每条记录为 商品名称和销售数量
        ArrayList<Object[]> result = DBCommonOperationWithoutJdbcDaoSupport.callQuery(sql, params);

        List<HotCommodity> products=new LinkedList<HotCommodity>();


        for(Object[] record:result)
        {
            HotCommodity hotCommodity=new HotCommodity();
            hotCommodity.setCommodity((String) record[0]);
            hotCommodity.setCnt(Integer.parseInt(record[1].toString()));
            products.add(hotCommodity);
        }
        return products;

    }


    /**
     * 获取指定商品在指定时间段内的每个月的销售量
     */
    public  List<ProductTrend>  hotProductTrend(String beginDate, String endDate, String commodityDescription) throws UnsupportedEncodingException {
//        String procName = "{call sp_select_hot_product_trend(?,?,?) }";
        //参数为开始日期、结束日期和商品名称
        //日期格式为YYYY-MM-DD
        String sql = "SELECT DATE_FORMAT(reviewDateTime,'%Y-%m') months,SUM(cnt)  FROM tb_receipt WHERE  commodityDescription= ? AND reviewDateTime>=? AND reviewDateTime<=? GROUP BY months";
        ArrayList<Object> params = new ArrayList<Object>();
        params.add(commodityDescription);
        params.add(beginDate);
        params.add(endDate);


        //返回值的每一行记录为 日期和该商品在该月中的销售数量
        ArrayList<Object[]> result = DBCommonOperationWithoutJdbcDaoSupport.callQuery(sql, params);
        List<ProductTrend> products=new LinkedList<ProductTrend>();


        for(Object[] record:result)
        {
            ProductTrend hotCommodity=new ProductTrend();
            hotCommodity.setMonthTime((String) record[0]);
            hotCommodity.setCnt(Integer.parseInt(record[1].toString()));
            hotCommodity.setCommodity(commodityDescription);
            System.out.println(hotCommodity);
            products.add(hotCommodity);
        }
        System.out.println(products.size());
        return products;

    }

    public List<HotCommodity> getHotProducts(Date beginDate, Date endDate){
        List<HotCommodity> products=null;
        //日期格式为YYYY-MM-DD

        String sql="select *  from tb_commodity_2_id   limit 0,1000";
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        for (Object[] objects:result) {
            HotCommodity hot=new HotCommodity();
            hot.setId((Integer) objects[0]);
            hot.setCommodity((String)objects[1]);
            hot.setCnt((Integer) objects[2]);
            products.add(hot);
        }
        return  products;
    }

    //select commodityDescription ,sum(cnt), SUM(amount) from tb_receipt where recPhone='13777876128' group by commodityDescription;
    public List<BuyRecord> fetchBuyRecordsWithoutRepeat(String phoneNumber) {
        List<BuyRecord> buyRecordList=new LinkedList<BuyRecord>();
        String sql="select commodityDescription ,sum(cnt) as cnt, SUM(amount) as amount, SUM(weight) as weight from tb_receipt where recPhone='"+phoneNumber+"' group by commodityDescription limit  0,1000;";
//        String sql="SELECT commodityDescription,cnt,amount,weight from tb_receipt   WHERE recPhone='"+phoneNumber+"' limit  1,1000";
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        for (Object[] objects:result) {

            BuyRecord buyRecord=new BuyRecord();
            buyRecord.setCommodityDescription((String) objects[0]);
            buyRecord.setCnt(Integer.parseInt(objects[1].toString()));
            buyRecord.setAmount(Integer.parseInt(objects[2].toString()));
            buyRecord.setWeight(Integer.parseInt(objects[3].toString()));
            buyRecordList.add(buyRecord);
        }

        return buyRecordList;
    }

    //select commodityDescription ,sum(cnt), SUM(amount) from tb_receipt where recPhone='13777876128' group by commodityDescription;
    public List<BuyRecord> fetchBuyRecordDetail(String commodityDescription, String phoneNumber) {
        List<BuyRecord> buyRecordList=new LinkedList<BuyRecord>();
        String sql="SELECT commodityDescription,cnt,amount,weight,receiverAddress,reviewDateTime from tb_receipt   WHERE recPhone='"+phoneNumber+"' AND commodityDescription="+"'"+commodityDescription+"' limit  0,1000";
//        String sql="SELECT commodityDescription,cnt,amount,weight from tb_receipt   WHERE recPhone='"+phoneNumber+"' limit  1,1000";
        System.out.println("-------------------------------"+sql);
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        for (Object[] objects:result) {

            BuyRecord buyRecord=new BuyRecord();
            buyRecord.setCommodityDescription((String) objects[0]);
            buyRecord.setCnt(Integer.parseInt(objects[1].toString()));
            buyRecord.setAmount(Integer.parseInt(objects[2].toString()));
            buyRecord.setWeight(Integer.parseInt(objects[3].toString()));
            buyRecord.setReceiverAddress((String) objects[4]);
            buyRecord.setReviewDateTime(((java.sql.Timestamp) objects[5]).toString());
            buyRecordList.add(buyRecord);
        }

        return buyRecordList;
    }

    public List<BuyRecord> fetchBuyRecords(String phoneNumber) {
        List<BuyRecord> buyRecordList=new LinkedList<BuyRecord>();
        String sql="SELECT commodityDescription,cnt,amount,weight from tb_receipt   WHERE recPhone='"+phoneNumber+"' limit  0,1000";
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        for (Object[] objects:result) {

            BuyRecord buyRecord=new BuyRecord();
            buyRecord.setCommodityDescription((String) objects[0]);
            buyRecord.setCnt(Integer.parseInt(objects[1].toString()));
            buyRecord.setAmount(Integer.parseInt(objects[2].toString()));
            buyRecord.setWeight(Integer.parseInt(objects[3].toString()));
            buyRecordList.add(buyRecord);
        }

        return buyRecordList;
    }

    //查询相关的人员，比如亲戚等等
    public String fetchSimilarCustomer(String phoneNumber) {
        String similarCustomer=null;
        String sql="SELECT cNames from tb_customer_community WHERE cPhone='"+phoneNumber+"'";
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        if (result!=null){
        similarCustomer=(String)result.get(0)[0];
        System.out.println("-----------------------similar------------------");
        System.out.println(phoneNumber+"       "+similarCustomer);
        }
        return similarCustomer;
    }

    //查询购买物品相似的人
    public List<Customer> fetchSimilarCustomer(Integer customId) {


        List<Customer> customerList=new LinkedList<Customer>();
        String sql="SELECT  detail.*,tmp.similarityValue FROM tb_customer detail, \n" +
                "\n" +
                "(SELECT cs.similarityValue,cs.similarityCId FROM tb_customer cd,tb_customer_similarity cs\n" +
                "\n" +
                "WHERE cd.id=cs.cId AND cd.id="+customId+") tmp\n" +
                "\n" +
                "WHERE tmp.similarityCId=detail.id;";
        //String sql="SELECT * from tb_customer WHERE id in(SELECT similarityCId FROM tb_customer_similarity WHERE cId="+customId+")";
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);

        for (Object[] objects:result) {
            Integer id=Integer.parseInt(objects[0].toString());
            String cName=(String)objects[1];
            Integer cAge=Integer.parseInt(objects[2].toString());
            Integer cGender=Integer.parseInt(objects[3].toString());
            String cIdNo=(String)objects[4];
            String cProvince=(String)objects[5];
            String cCity=(String)objects[6];
            String cDistrict=(String)objects[7];
            String cAddress=(String)objects[8];
            String cPhone=(String)objects[9];
            Integer cTotalSum=Integer.parseInt(objects[10].toString());
            Integer similarityValue=Integer.parseInt(objects[11].toString());
            Customer customer=new Customer(id, cName, cAge,  cGender, cIdNo, cProvince,  cCity,
                    cDistrict, cAddress, cPhone, cTotalSum,similarityValue);

            customerList.add(customer);
        }

        return customerList;
    }
}
