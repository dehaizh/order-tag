package cn.edu.ustc.dehaizh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by dehaizh on 2016/4/19.
 */
@Controller
public class ExceptionController {

    @RequestMapping(value = "/error/403")
    public String pageNotFound(HttpServletRequest request)
    {
        //request.getSession().removeAttribute("user");
        return "error/403";
    }

    @RequestMapping(value = "/error/500")
    public String innerError(HttpServletRequest request)
    {
        //request.getSession().removeAttribute("user");

        return "error/500";
    }
}
