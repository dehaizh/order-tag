package cn.edu.ustc.dehaizh.domain;

import org.springframework.stereotype.Component;

/**
 * Created by dehaizh on 2016/3/17.
 */
@Component
public class Mail {

    private int id;
    private String sentDate;
    private String mailFrom;
    private String mailSubject;
    private String content;
    private int hasRead;
    private int isDeleted;
    private String response;
    private String mailCategory;
    private int confused;
    private String mailOuterCategory;
    private String addReplyOperator;
    private String addReplyDate;


    public Mail() {
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSentDate() {
        return sentDate;
    }

    public void setSentDate(String sentDate) {
        this.sentDate = sentDate;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public void setMailFrom(String mailFrom) {
        this.mailFrom = mailFrom;
    }

    public String getMailOuterCategory() {
        return mailOuterCategory;
    }

    public String getAddReplyDate() {
        return addReplyDate;
    }

    public void setAddReplyDate(String addReplyDate) {
        this.addReplyDate = addReplyDate;
    }

    public String getAddReplyOperator() {
        return addReplyOperator;
    }

    public void setAddReplyOperator(String addReplyOperator) {
        this.addReplyOperator = addReplyOperator;
    }

    public void setMailOuterCategory(String mailOuterCategory) {
        this.mailOuterCategory = mailOuterCategory;
    }

    public String getMailSubject() {
        return mailSubject;
    }

    public void setMailSubject(String mailSubject) {
        this.mailSubject = mailSubject;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getHasRead() {
        return hasRead;
    }

    public void setHasRead(int hasRead) {
        this.hasRead = hasRead;
    }

    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getMailCategory() {
        return mailCategory;
    }

    public void setMailCategory(String mailCategory) {
        this.mailCategory = mailCategory;
    }

    public int getConfused() {
        return confused;
    }

    public void setConfused(int confused) {
        this.confused = confused;
    }



}
