package cn.edu.ustc.dehaizh.xlsx;

import java.io.File;
import java.io.IOException;

public final class FileSearcher {
	//私有构造器增强不可实例化的能力
	//private FileSearcher(){}
	
	private static final String[] EMPTY_FILENAME_ARRAY = new String[0];
	
	/**
	 * 
	 * @param dirpath 文件所在的目录的绝对路径
	 * @param filenameExtension 文件的后缀名,如xls, *表示所有的文件类型
	 * @return 指定类型文件的文件名(非绝对路径)数组,如果没有指定指定的文件，则返回长度为0的空数组
	 * @throws IOException 如果不存在指定的目录
	 */
	public static String[] getFilenames(String dirpath, String filenameExtension) throws IOException
	{
		String[] filenames = EMPTY_FILENAME_ARRAY;
		File dir = new File(dirpath);
		if(dir.isDirectory())
			filenames = dir.list(new MyFilenameFilter(filenameExtension));
		else 
			throw new IOException("invalid directory: "+dirpath);
		//返回长度为0的数组，而不是返回null，这样更加有利于前台调用
		if(filenames == null || filenames.length==0)
			filenames = EMPTY_FILENAME_ARRAY;
		return filenames;
	}
	
	/**
	 * 
	 * @param dirpath 	指定目录的绝对路径
	 * @param filenameExtension	查找的文件的扩展名
	 * @return	返回满足指定条件的文件的绝对路径数组，如果没有满足条件的文件，则返回一个长度为0的数组，而不是null
	 * @throws IOException
	 */
	public static String[] getAbsoluteFilenames(String dirpath, String filenameExtension) throws IOException
	{
		String[] filenames = EMPTY_FILENAME_ARRAY;
		File dir = new File(dirpath);
		if(!dir.isDirectory())
			throw new IOException("invalid directory: "+dirpath);
		File[] files = dir.listFiles(new MyFilenameFilter(filenameExtension));
		int i=0;
		int numOfFiles = files.length;
		filenames = new String[numOfFiles];
		for(File file :files)
		{
			filenames[i++] = file.getAbsolutePath();
		}
		//filenames = dir.list(new MyFilenameFilter(filenameExtension));
			
		//返回长度为0的数组，而不是返回null，这样更加有利于前台调用
		if(filenames == null || filenames.length==0)
			filenames = EMPTY_FILENAME_ARRAY;
		return filenames;
		
	}
	
	public static boolean fileExists(String filename)
	{
		return new File(filename).exists();
	}
	
}
