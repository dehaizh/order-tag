package cn.edu.ustc.dehaizh.util;

import com.aliasi.symbol.SymbolTable;

import java.io.Serializable;
import java.util.HashMap;
import java.util.concurrent.ArrayBlockingQueue;

/**
 * Created by dehaizh on 2016/4/23.
 */
public class Symbol2Id implements Serializable {
    private HashMap<String,Integer> symbol2Id;
    private HashMap<Integer,String> id2Symbol;
    private int id=0;

    public Symbol2Id() {}

    public void symbol2Id(String symbol)
    {
        if(!symbol.contains(symbol))
        {
            symbol2Id.put(symbol,id);
            ++id;
        }
    }

    public String id2Symbol(int id)
    {
        return id2Symbol.get(id);
    }

    public static void main(String[] args) {


    }

}
