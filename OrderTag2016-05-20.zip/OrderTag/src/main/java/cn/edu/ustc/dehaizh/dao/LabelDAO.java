package cn.edu.ustc.dehaizh.dao;

import cn.edu.ustc.dehaizh.domain.LabelDetail;
import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by root on 16-5-5.
 */
@Repository("labelDAO")
public class LabelDAO {

    public List<String> getAgeCategory(){
        List<String> ageCategory=new LinkedList<String>();
        String sql="SELECT lCategory FROM tb_label WHERE lParentCategory='年龄段'";
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        for (Object[] objects:result) {

            ageCategory.add((String)objects[0]);
//            for (int i = 0; i < objects.length; i++) {
//                System.out.println("---------------1----------------");
//                System.out.println(objects[0]);
//            }
        }
        return ageCategory;
    }

//    public List<String> getAreaCategory() {
//        List<String>areaCategory=new LinkedList<String>();
//        return areaCategory;
//    }

    public List<String> getTageCategory() {
        List<String> tageCategory=new LinkedList<String>();
        String sql="SELECT lCategory FROM tb_label WHERE lParentCategory='消费级别'";
        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        for (Object[] objects:result) {

            tageCategory.add((String)objects[0]);
//            for (int i = 0; i < objects.length; i++) {
//                System.out.println("---------------2----------------");
//                System.out.println(objects[0]);
//            }
        }
        return tageCategory;
    }

//SELECT * from tb_customer_label_detail  where find_in_set('中年', labelDetail) and find_in_set('土豪', labelDetail);;

    public LabelDetail fetchLabelDetail(Integer customerid){

        LabelDetail label=null;
        String sql="SELECT * from tb_customer_label_detail where customerId = "+customerid;

        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);
        for (Object[] objects:result) {
            Integer customerId=Integer.parseInt(objects[0].toString());
            String labelDetail=(String)objects[1];
            String cGender=(String)objects[2];
            String cName=(String)objects[3];
            Integer cAge=Integer.parseInt(objects[4].toString());
            String cIdNo=(String)objects[5];
            String cPhone=(String)objects[6];
            Integer cTotalSum=Integer.parseInt(objects[7].toString());
            String cProvince=(String)objects[8];
            String cCity=(String)objects[9];
            String cAddress=(String)objects[10];

            label=new LabelDetail( customerId,  labelDetail,  cGender,  cName,  cAge,
                    cIdNo,  cPhone,  cTotalSum,  cProvince,  cCity,  cAddress);

//            for (int i = 0; i < objects.length; i++) {
//                System.out.println("---------------2----------------");
//                System.out.println(objects[0]);
//            }
        }
        return label;
    }


    public List<LabelDetail> fetchLabelDetail(String startDate, String endDate,
                                              String ageCategory, String areaCategory,
                                              String tageCategory, String sex ){
        List<LabelDetail> labelDetailList=new LinkedList<LabelDetail>();

        StringBuffer sqlBuffer=new StringBuffer("SELECT * from tb_customer_label_detail where 1=1 \n");

        String sql;

            if (startDate!=null){
                sqlBuffer.append("");
            }if (endDate!=null){
                sqlBuffer.append("");
            }            //startDate endDate暂时未曾处理
            if (ageCategory!=null){
                sqlBuffer.append("and find_in_set('").append(ageCategory).append("',").append(" labelDetail)\n");
            }if (tageCategory!=null){
                sqlBuffer.append("and find_in_set('").append(tageCategory).append("',").append(" labelDetail)\n");
            }if (areaCategory!=null){
                sqlBuffer.append("and cCity='").append(areaCategory).append("'\n");
            }if (sex!=null){
                sqlBuffer.append("and cGender='").append(sex).append("'\n");
            }
            sqlBuffer.append(" LIMIT 1000;");
            sql=sqlBuffer.toString();

        System.out.println(sql.toString());

        ArrayList<Object[]> result= DBCommonOperationWithoutJdbcDaoSupport.executeQuery(sql,null);

        for (Object[] objects:result) {
            Integer customerId=Integer.parseInt(objects[0].toString());
            String labelDetail=(String)objects[1];
            String cGender=(String)objects[2];
            String cName=(String)objects[3];
            Integer cAge=Integer.parseInt(objects[4].toString());
            String cIdNo=(String)objects[5];
            String cPhone=(String)objects[6];
            Integer cTotalSum=Integer.parseInt(objects[7].toString());
            String cProvince=(String)objects[8];
            String cCity=(String)objects[9];
            String cAddress=(String)objects[10];
            LabelDetail label=new LabelDetail( customerId,  labelDetail,  cGender,  cName,  cAge,
                    cIdNo,  cPhone,  cTotalSum,  cProvince,  cCity,  cAddress);
            labelDetailList.add(label);
        }
        return labelDetailList;
    }

    public static void main(String[] args) {
        LabelDAO labelDAO=new LabelDAO();
        labelDAO.fetchLabelDetail("11","22","青年","合肥","土豪","男");
    }
}
