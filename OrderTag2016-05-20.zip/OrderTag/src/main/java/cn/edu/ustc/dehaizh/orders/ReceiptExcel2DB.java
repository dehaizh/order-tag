package cn.edu.ustc.dehaizh.orders;

import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;
import cn.edu.ustc.dehaizh.xlsx.FileSearcher;
import cn.edu.ustc.dehaizh.xlsx.XLSXReader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by dehaizh on 2016/4/22.
 */
public class ReceiptExcel2DB {
    //用于匹配手机号码
//    private final static String REGEX_MOBILEPHONE = "^0?1[3458]\\d{9}$";
    //用于匹配以0打头的手机号码 比如 013834563587
    private final static String REGEX_MOBILEPHONE = "^01[3458]\\d{4,9}$";
    private static Pattern PATTERN_MOBILEPHONE = Pattern.compile(REGEX_MOBILEPHONE);

    public static void file2DB(String fileDir,String fileExt) throws IOException {

        String[] filenames = FileSearcher.getAbsoluteFilenames(fileDir, fileExt);
        System.out.printf("--------------- 待处理的文件个数:%-4d--------------\r\n", filenames.length);
//        ArrayPrinter.print(filenames);

        String sql = "INSERT INTO tb_receipt(airWayBillNO,customsBillNo,originalBillNo,postTo,gate,customsCommand,detectCommand,taxStatus,receiverName,receiverAddress,recProvince,recCity,recDistrict,originalRecPhone,recPhone,originalCommodityDescription,commodityDescription,cnt,amount,weight,recPostalcode,notes,senderName,senderAddress,senderPhone,orderNo,customsPai,detectPai,packageNo,customsDeclarationNo,reviewDateTime,xRayDateTime,xRayNo,declarationDateTime,processedDateTime,filename) " +
                "  VALUES (?, ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? ,?, ?, ? , ? , ? , ? , ? , ? , ? ,? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?, ? ) ";
        int numOfFiles = filenames.length;
        int numOfThread = 6;    //线程数目
        ExecutorService threadPool = Executors.newFixedThreadPool(numOfThread);
        CountDownLatch latch = new CountDownLatch(numOfFiles);
        for(String filename:filenames)
        {
            File2DBRunnable runnable = new File2DBRunnable(filename, latch, sql);
            //单线程
//            runnable.run();
            //多线程
            threadPool.execute(runnable);
        }
        //关闭线程池，不在接受新的任务，等待当前提交的任务处理结束
        threadPool.shutdown();

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("文件处理完毕");

    }

    static class File2DBRunnable implements Runnable{
        private String filename;
        private CountDownLatch latch;
        private String sql;

        public File2DBRunnable(String filename, CountDownLatch latch, String sql) {
            //defensive copying
            this.filename = new String(filename);
            this.latch = latch;
            this.sql = new String( sql );
        }

        public File2DBRunnable(String filename, CountDownLatch latch) {
            //defensive copying
            this.filename = new String(filename);

            this.latch = latch;
        }

        public void run() {
            XLSXReader reader = null;
            try {
                System.out.println("----------------正在处理文件"+filename+"-----------------------");
                reader = new XLSXReader(filename);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(reader!=null)
            {
                int numOfSheets = reader.getNumOfSheets();
                for(int i=0;i<numOfSheets;++i)
                {
                    ArrayList<ArrayList<String>> lists = reader.readExcelSheet(i);
                    ArrayList<Object[]> params = prepareParameters(lists);

                    try {
                        //dump file into db
                        DBCommonOperationWithoutJdbcDaoSupport.batch(sql, params);
                    }catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }

            }
            //count--
            latch.countDown();
        }

        private ArrayList<Object[]> prepareParameters(ArrayList<ArrayList<String>> lists) {
            ArrayList<Object[]> ret = new ArrayList<Object[]>();
            int numOfRecords = lists.size();
            for(int i=1;i<numOfRecords;++i)
            {
//            for(ArrayList<String> row:lists)
//            {
                ArrayList<String> row = lists.get(i);
                Object[] record = new Object[36];
                //总运单号
                record[0] = row.get(1);
                if(record[0].toString().length()<1)
                    break;

                //海关清单标号
                record[1] = row.get(2);
                //原始清单编号
                record[2] = row.get(3);
                //路向
                record[3] = row.get(4);
                //格口
                record[4] = row.get(5);

                //海关指令
                record[5] = row.get(6);
                //国检指令
                record[6] = row.get(7);
                //征免状态
                record[7] = row.get(8);
                //收件人
                record[8] = row.get(9);
                //收件人地址
                record[9] = row.get(10);
                //收件人省份
                record[10] = row.get(11);
                //收件人城市
                record[11] = row.get(12);
                //收件人区县
                record[12] = row.get(13);

                //收件人电话(原始电话信息)
                record[13] = row.get(14);

                String cPhone = row.get(14);
                //剔除电话号码中的不合法的字符，比如+86,',0086等等
                record[14] = correctReceiverPhone(cPhone);

                //主要商品描述（原始商品描述信息）
                record[15] = row.get(15);

                String commodityDescription = row.get(15);
                //去除商品描述信息中的不合法字符
                record[16] = correctCommodityDescription(commodityDescription);

                //件数
                record[17] = 0;
                String numOfCommodity = "";
                {
                    numOfCommodity = row.get(16);
                    if(numOfCommodity.length()>0)
                    {
                        try {
                            record[17] = Math.abs(Integer.parseInt(numOfCommodity));
                        }catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                }

                //商品总价，数据库中存储值=文件值*100;
                record[18] = 0;
                try {
                    record[18]=(int)(Float.parseFloat(row.get(17))*100);
                }catch (Exception e)
                {
                    e.printStackTrace();
                }


                //毛重，数据库中存储值=文件值*100
                record[19] =0;
                try {
                    record[19]=(int)(Float.parseFloat(row.get(18).replaceAll("-",""))*100);
                }catch (Exception e)
                {
                    e.printStackTrace();
                }

                //收件人邮编
                record[20] = row.get(19);
                //备注
                record[21] = row.get(20);
                //发件人姓名
                record[22] = row.get(21);
                //发件人地址
                record[23] = row.get(22);
                //发件人电话
                record[24] = row.get(23);
                //运单号
                record[25] = row.get(24);
                //海关拍
                record[26] = row.get(25);
                //国检拍
                record[27] = row.get(26);
                //袋号
                record[28] = row.get(27);
                //报关单号
                record[29] = row.get(28);
                //审核时间
                record[30] = row.get(29);
                //过X光机时间
                record[31] = row.get(30);

                //X光机编号
                record[32] = row.get(31);

                //申报日期
                record[33] =null;
                if(row.get(33).length()>0){
                    try {
                        record[33] = row.get(33);
                    }catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                //添加文件处理时间，
                //使用timestamp类型，当赋值为null时，则表示当前日期时间
                record[34] = null;
                //文件名
                record[35] = filename;
                //将记录添加到list中
                ret.add(record);
            }
            return ret;
        }

        private String correctCommodityDescription(String commodityDescription) {
            //去除首尾的空白字符
            commodityDescription = commodityDescription.trim();
            //商品描述信息转换为小写
            commodityDescription = commodityDescription.toLowerCase();

            //去除（(中文左括号)
            if (commodityDescription.contains("（"))
            {
                commodityDescription = commodityDescription.replaceAll("（","");
            }

            //去除）(中文右括号)
            if (commodityDescription.contains("）"))
            {
                commodityDescription = commodityDescription.replaceAll("）","");
            }

            //去除((英文左括号)
            if (commodityDescription.contains("("))
            {
                commodityDescription = commodityDescription.replaceAll("\\(","");
            }

            //去除)(英文右括号)
            if (commodityDescription.contains(")"))
            {
                commodityDescription = commodityDescription.replaceAll("\\)","");
            }

            //去除'(英文引号)
            if (commodityDescription.contains("'"))
            {
                commodityDescription = commodityDescription.replaceAll("'","");
            }

            //去除-(英文引号)
            if (commodityDescription.contains("-"))
            {
                commodityDescription = commodityDescription.replaceAll("-","");
            }

            //将中文的克替换为g
            if (commodityDescription.contains("克"))
            {
                commodityDescription = commodityDescription.replace("克", "g");
            }

            //将中文的 4段 替换为 四段
            if (commodityDescription.contains("4段"))
            {
                commodityDescription = commodityDescription.replace("4段","四段");
            }

            //将中文的 3段 替换为 三段
            if (commodityDescription.contains("3段"))
            {
                commodityDescription = commodityDescription.replace("3段","三段");
            }

            //将中文的 2段 替换为二段
            if (commodityDescription.contains("2段"))
            {
                commodityDescription = commodityDescription.replace("2段","二段");
            }

            //将中文的 1段 替换为 一段
            if (commodityDescription.contains("1段"))
            {
                commodityDescription = commodityDescription.replace("1段","一段");
            }

            commodityDescription = commodityDescription.trim();

            return commodityDescription;
        }

        /**
         * 2016-05-10
         * 对收件人的电话号码进行校正，去除电话号码中多余的字符
         * @param cPhone
         * @return
         */
        private String correctReceiverPhone(String cPhone) {
            if(cPhone!=null&&cPhone.length()>0)
            {
                cPhone = cPhone.toLowerCase();
                cPhone = cPhone.trim();

                //处理86类型的手机号码
                if(cPhone.startsWith("+86 "))
                {//号码已+86空格 开头
                    cPhone = cPhone.replace("+86 ","");
                }else if(cPhone.startsWith("+86-"))
                {//号码以+86-开头
                    cPhone = cPhone.replace("+86-","");
                }else if(cPhone.startsWith("+86"))
                {//号码以+86开头
                    cPhone = cPhone.replace("+86","");
                }else if(cPhone.startsWith("0086-"))
                {//号码以0086-开头
                    cPhone = cPhone.replace("0086-","");
                }else if(cPhone.startsWith("0086"))
                {//号码以0086开头
                    cPhone = cPhone.replace("0086","");
                }
                //这个是＋86
                //不是这+86
                if(cPhone.startsWith("＋86"))
                {//号码中包含"＋86"
                    cPhone = cPhone.replace("＋86","");
                }

                //这个不是+(加号)，是＋
                if(cPhone.startsWith("＋81"))
                {//号码以＋81开头
                    cPhone = cPhone.replace("＋81","");
                }

                if(cPhone.startsWith("/"))
                    cPhone=cPhone.replace("/","");

                if(cPhone.contains("-"))
                    cPhone=cPhone.replace("-","");

                //这个是－
                //不是-
                if(cPhone.contains("－"))
                    cPhone=cPhone.replace("－","");
                if(cPhone.contains("一"))
                    cPhone=cPhone.replace("一","");

                if(cPhone.contains("!"))
                {//号码中包含！号
                    cPhone = cPhone.replace("!","");
                }

                if(cPhone.contains("'"))
                {//号码中包含'号(单引号)
                    cPhone = cPhone.replace("'","");
                }

                if(cPhone.contains("，"))
                {//号码中包含，号(中文逗号)
                    cPhone = cPhone.replace("，","");
                }

                if(cPhone.contains(","))
                {//号码中包含,号(英文逗号)
                    cPhone = cPhone.replace(",","");
                }

                if(cPhone.contains("？"))
                {//号码中包含？号(中文问号)
                    cPhone = cPhone.replace("？","");
                }

                if(cPhone.contains("?"))
                {//号码中包含?号(英文问号)
                    cPhone = cPhone.replace("?","");
                }

                //判断电话号码是否以0开头 比如 013834567892
                Matcher matcher = PATTERN_MOBILEPHONE.matcher(cPhone);
                if (matcher.matches())
                {
                    cPhone = cPhone.substring(1);
                }

                cPhone = cPhone.trim();

//                int phoneNum = (cPhone.length()<=12)?cPhone.length():12;
//                cPhone = cPhone.substring(0,phoneNum);

            }
            return cPhone;
        }

    }

    public static void main(String[] args) throws IOException {

        String fileDir = "D:/WmGlobalOrdersTagMining/WmOrdersReceipt";
        String fileExt = "*";
        ReceiptExcel2DB.file2DB(fileDir, fileExt);

        System.out.println("Finished...");

    }

}
