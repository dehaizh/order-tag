package cn.edu.ustc.dehaizh.orders;

import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;

import java.util.ArrayList;

/**
 * Created by dehaizh on 2016/5/6.
 */
public class BuildCustomerTag {

    private static String SELECT_CUSTOMER_INFO_FROM_TB_CUSTOMER="SELECT c.id,c.cAge,c.totalSum,c.cGender,c.cCity," +
                                                                " diff.diffLastNameCnt,diff.diffNameCnt,diff.orderCnt,diff.dateDiff " +
                                                                " FROM tb_customer c JOIN tb_customer_diff_lastname_order_frequency diff ON c.id=diff.cId";
    private static String INSERT_TB_CUSTOMER_LABEL="INSERT INTO tb_customer_label(customerId,labelId) VALUES(?,?)";

    public static void buildTag()
    {
        ArrayList<Object[]> customers = fetchCustomers();

        ArrayList<Object[]> list = new ArrayList<Object[]>();
        for(Object[] record:customers)
        {
            int cId = Integer.parseInt(record[0].toString());
            int cAge =Integer.parseInt(record[1].toString());
            int cSum = Integer.parseInt(record[2].toString());
            int cGender = Integer.parseInt(record[3].toString());
            String cCity = record[4].toString();
            int cDiffLastnameCnt = Integer.parseInt(record[5].toString());
            int cDiffNameCnt = Integer.parseInt(record[6].toString());
            int cOrderCnt = Integer.parseInt(record[7].toString());
            int cDateDiff = Integer.parseInt(record[8].toString());

            //返回值 1=大城市，2=小城市
            int cityLabel = getCityLabel(cCity);
            //返回值 3=少年，4=青年，5=中年，6=老年
            int ageLabel = getAgeLabel(cAge);
            //消费级别 返回值 7=土豪 8=小资 9=普通工薪 10=屌丝
            int sumLabel = getSumLabel(cSum);
            int genderLabel = getGenderLabel(cGender);
            int customerLabel = getCustomerLabel(cDiffLastnameCnt,cDiffNameCnt,cOrderCnt,cDateDiff);

            //城市标签
            Object[] cityLabelRecord = new Object[2];
            cityLabelRecord[0] = cId;
            cityLabelRecord[1] = cityLabel;

            //年龄标签
            Object[] ageLableRecord = new Object[2];
            ageLableRecord[0] = cId;
            ageLableRecord[1] = ageLabel;

            //总消费金额Label
            Object[] sumLableRecord = new Object[2];
            sumLableRecord[0] = cId;
            sumLableRecord[1] = sumLabel;

            //性别标签
            Object[] genderLabelRecord = new Object[2];
            genderLabelRecord[0] = cId;
            genderLabelRecord[1] = genderLabel;

            //客户类别
            Object[] customerLabelRecord = new Object[2];
            customerLabelRecord[0] = cId;
            customerLabelRecord[1] = customerLabel;

            list.add(cityLabelRecord);
            list.add(ageLableRecord);
            list.add(sumLableRecord);
            list.add(genderLabelRecord);
            list.add(customerLabelRecord);

        }

        //将客户标签添加到数据库表 tb_customer_label中
        DBCommonOperationWithoutJdbcDaoSupport.batch(INSERT_TB_CUSTOMER_LABEL, list);

    }

    /**
     * 确定客户是否是小B
     * @param cDiffLastnameCnt
     * @param cDiffNameCnt
     * @param cOrderCnt
     * @param cDateDiff
     * @return 14=个体 15=疑似小B 16=确定小B
     * score = -(DiffLastNameCnt-4)+3*(diffNameCnt/diffLastNameCnt) + (dateDiff/orderCnt)*0.5
     */
    private static int getCustomerLabel(int cDiffLastnameCnt, int cDiffNameCnt, int cOrderCnt, int cDateDiff) {
        int customerLabel=14;//默认是个体
        if (cDiffLastnameCnt<=4)
            customerLabel = 14;//个体
        else if(cDiffLastnameCnt>6)
            customerLabel=16;//确定小B
        else //（4,6]
        {//不同姓的数目为5,6
            double score = 0;

            score = -(cDiffLastnameCnt-4)+3.0*(cDiffNameCnt/cDiffLastnameCnt)+0.5*(cDateDiff/cOrderCnt);
            if(1.8<score &&score<2.4)//疑似小B
                customerLabel=15;
            if(score>=2.4)
                customerLabel=14;//个体
            else
                customerLabel=16;//确定小B
        }

        return  customerLabel;
    }

    /**
     * 性别标签
     * @param cGender 0,1
     * @return 0=11(欧巴) 1=12(美眉) 13(UNKNOW)
     */
    private static int getGenderLabel(int cGender) {
        return (cGender==0)?11:12;
    }

    /**
     * 解析城市标签
     * @param cCity
     * @return 1=大城市；2=小城市；详细定义请参看表tb_label
     */
    private static int getCityLabel(String cCity) {
        if(cCity.contains("北京") || cCity.contains("上海") || cCity.contains("广州") || cCity.contains("北京")|| cCity.contains("深圳") )
            return 1;
        return 2;
    }

    /**
     * 设置消费级别标签
     * @param cSum 消费总金额
     * @return 7=土豪 8=小资 9=普通工薪 10=屌丝
     */
    private static int getSumLabel(int cSum) {
        int sumLabel = 9; //默认为普通工薪层
        if(cSum<=100)  //屌丝
            sumLabel = 10;
        else if(cSum<=200000) //普通工薪
            sumLabel= 9;
        else if(cSum<=1000000) //小资
            sumLabel= 8;
        else sumLabel=7; //土豪
        return  sumLabel;
    }

    /**
     * 获取年龄对应的年龄标记，具体定义请参看tb_label
     * @param cAge int
     * @return (cAge<=17)=3,(18<=cAge<=40)=4,(40<cAge<=65)=5,
     * (cAge>65)=6,具体定义请参看tb_label
     */
    private static int getAgeLabel(int cAge) {
        int ageLabel = 4; //默认年龄段是 青年(18<=cAge<=40)
        if(cAge<18)
            ageLabel = 3;
        else if(cAge<=40)
            ageLabel= 4;
        else if(cAge<=65)
            ageLabel= 5;
        else ageLabel=6;
        return ageLabel;
    }

    private static ArrayList<Object[]> fetchCustomers() {
        return DBCommonOperationWithoutJdbcDaoSupport.executeQuery(SELECT_CUSTOMER_INFO_FROM_TB_CUSTOMER, null);
    }

    public static void main(String[] args) {

        System.out.printf("-------------------- %40s ----------------------\r\n","正在清空表tb_customer_label中的数据");
        String TRUNCATE_TB_CUSTOMER_LABEL="TRUNCATE TABLE tb_customer_label;";
        DBCommonOperationWithoutJdbcDaoSupport.executeNonQuery(TRUNCATE_TB_CUSTOMER_LABEL, null);

        System.out.printf("------------------- %40s -------------------------\r\n", "正在建立客户标签");

        BuildCustomerTag.buildTag();

        System.out.printf("------------------- %40s -------------------------\r\n","客户标签建立完成");

    }

}
