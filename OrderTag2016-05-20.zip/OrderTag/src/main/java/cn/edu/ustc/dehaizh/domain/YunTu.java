package cn.edu.ustc.dehaizh.domain;

/**
 * Created by root on 16-5-6.
 */


public class YunTu {
    //标签id,可用于显示位置
    private Integer id;
    //标签名称
    private String label;
    //标签字体颜色
    private YunTuColor color;
    //权重
    private double weight;
    //字体大小
    private int fontSize;

    public int getFontSize() {
        return fontSize;
    }

    public void setFontSize(int fontSize) {
        this.fontSize = fontSize;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public YunTuColor getColor() {
        return color;
    }

    public void setColor(YunTuColor color) {
        this.color = color;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
