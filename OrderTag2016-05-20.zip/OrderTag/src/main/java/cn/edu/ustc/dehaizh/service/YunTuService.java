package cn.edu.ustc.dehaizh.service;

import cn.edu.ustc.dehaizh.dao.LabelDAO;
import cn.edu.ustc.dehaizh.domain.LabelDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by root on 16-5-5.
 */
@Service
public class YunTuService {
    @Autowired
    private LabelDAO labelDAO;

    public List<String> getAgeCategory(){
        return labelDAO.getAgeCategory();
    }

    //消费级别
    public List<String> getTageCategory(){
        return labelDAO.getTageCategory();
    }

    public List<LabelDetail> fetchLabelDetail(String startDate, String endDate,
                                              String ageCategory, String areaCategory,
                                              String tageCategory, String sex ){
        return labelDAO.fetchLabelDetail(startDate,endDate,ageCategory,areaCategory,tageCategory,sex);
    }

    public LabelDetail fetchLabelDetail(Integer customerid){
        return labelDAO.fetchLabelDetail(customerid);
    }
}
