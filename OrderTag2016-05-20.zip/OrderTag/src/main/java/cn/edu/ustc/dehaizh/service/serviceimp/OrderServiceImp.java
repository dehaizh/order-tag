package cn.edu.ustc.dehaizh.service.serviceimp;

import cn.edu.ustc.dehaizh.dao.OrderDAO;
import cn.edu.ustc.dehaizh.domain.BuyRecord;
import cn.edu.ustc.dehaizh.domain.Customer;
import cn.edu.ustc.dehaizh.domain.HotCommodity;
import cn.edu.ustc.dehaizh.domain.ProductTrend;
import cn.edu.ustc.dehaizh.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;

/**
 * Created by root on 16-5-5.
 */
@Service("orderService")
public class OrderServiceImp implements OrderService {

    @Autowired
    private OrderDAO orderDAO;

    public List<HotCommodity> getHotProducts() {
        return orderDAO.getHotProducts();
    }

    public List<HotCommodity> getHotProducts(Date beginDate, Date endDate) {
        return null;
    }

    public List<BuyRecord> fetchBuyRecords(String phoneNumber) {
        return orderDAO.fetchBuyRecords(phoneNumber) ;
    }

    public String fetchSimilarCustomer(String phoneNumber) {
        return orderDAO.fetchSimilarCustomer(phoneNumber);
    }

    public List<Customer> fetchSimilarCustomer(Integer customId) {
        return orderDAO.fetchSimilarCustomer(customId);
    }

    public List<BuyRecord> fetchBuyRecordsWithoutRepeat(String phoneNumber) {
        return orderDAO.fetchBuyRecordsWithoutRepeat(phoneNumber);
    }

    public List<BuyRecord> fetchBuyRecordDetail(String commodityDescription, String phoneNumber) {
        return orderDAO.fetchBuyRecordDetail(commodityDescription,phoneNumber);
    }

    public List<HotCommodity> getHotProduct(String beginDate, String endDate) {
        return orderDAO.getHotProduct(beginDate,endDate);
    }

    public List<ProductTrend> hotProductTrend(String beginDate, String endDate, String commodityDescription) throws UnsupportedEncodingException {
        return orderDAO.hotProductTrend(beginDate,endDate,commodityDescription);
    }
}
