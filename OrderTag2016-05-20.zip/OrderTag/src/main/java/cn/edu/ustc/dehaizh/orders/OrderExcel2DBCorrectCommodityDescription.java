package cn.edu.ustc.dehaizh.orders;

import cn.edu.ustc.dehaizh.util.ArrayPrinter;
import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;
import cn.edu.ustc.dehaizh.xlsx.FileSearcher;
import cn.edu.ustc.dehaizh.xlsx.XLSXReader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by dehaizh on 2016/4/22.
 */
public class OrderExcel2DBCorrectCommodityDescription {
    public static void file2DB(String fileDir,String fileExt) throws IOException {

        String[] filenames = FileSearcher.getAbsoluteFilenames(fileDir, fileExt);
        System.out.println( filenames.length );
        ArrayPrinter.print(filenames);

        String sql = "INSERT INTO tb_orders(airWayBillNo,customsBillNo,orderNo,commodityDescription,receiverName,recIdNo,customsCommand,detectCommand,orderProcessedDate,filename,processedDateTime) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
        int numOfFiles = filenames.length;
        int numOfThread = 6;    //线程数目
        ExecutorService threadPool = Executors.newFixedThreadPool(numOfThread);
        CountDownLatch latch = new CountDownLatch(numOfFiles);
        for(String filename:filenames)
        {
            File2DBRunnable runnable = new File2DBRunnable(filename, latch, sql);
            //单线程
//            runnable.run();
            //多线程
            threadPool.execute(runnable);
        }
        //关闭线程池，不在接受新的任务，等待当前提交的任务处理结束
        threadPool.shutdown();

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.printf("--------------- %4d 个账单文件成功dump到数据库中 -------------\r\n", numOfFiles);

        DeleteDuplicateRecordFromTbOrders.deleteDuplicateRecord();
    }

    static class File2DBRunnable implements Runnable{
        private String filename;
        private CountDownLatch latch;
        private String sql;

        public File2DBRunnable(String filename, CountDownLatch latch, String sql) {
            //defensive copying
            this.filename = new String(filename);
            this.latch = latch;
            this.sql = new String( sql );
        }

        public File2DBRunnable(String filename, CountDownLatch latch) {
            //defensive copying
            this.filename = new String(filename);

            this.latch = latch;
        }

        public void run() {
            XLSXReader reader = null;
            try {
                System.out.println("----------------正在处理文件"+filename+"-----------------------");
                reader = new XLSXReader(filename);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(reader!=null)
            {
                int numOfSheets = reader.getNumOfSheets();
                for(int i=0;i<numOfSheets;++i)
                {
                    ArrayList<ArrayList<String>> lists = reader.readExcelSheet(i);
                    ArrayList<Object[]> params = prepareParameters(lists);
                    
                    try {
                        //dump file into db
                        DBCommonOperationWithoutJdbcDaoSupport.batch(sql, params);
                    }catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                }

            }
            //count--
            latch.countDown();
        }

        private ArrayList<Object[]> prepareParameters(ArrayList<ArrayList<String>> lists) {
            ArrayList<Object[]> ret = new ArrayList<Object[]>();
            int numOfRecords = lists.size();
            for(int i=1;i<numOfRecords;++i)
            {
//            for(ArrayList<String> row:lists)
//            {
                ArrayList<String> row = lists.get(i);
                Object[] record = new Object[11];
                //总运单号
                record[0] = row.get(0);
                if(record[0].toString().length()<1)
                    break;

                //海关清单编号
                record[1] = row.get(1);
                //分运单号，订单编号
                record[2] = row.get(2);
                //商品信息描述
                record[3] = "";
                String commodityDescription = correctCommodityDescription(row.get(3));
                record[3] = commodityDescription;

                //收件人
                record[4] = row.get(4);

                //证件号码
                record[5] = row.get(5);
                //海关指令
                record[6] = row.get(6);
                //国检指令
                record[7] = row.get(7);
                //处理时间
                record[8] = row.get(8);
                //文件名
                record[9] = filename;
                //处理时间
                record[10] = null;

                //将记录添加到list中
                ret.add(record);
            }
            return ret;
        }

        private String correctCommodityDescription(String commodityDescription) {
            //去除首尾的空白字符
            commodityDescription = commodityDescription.trim();
            //商品描述信息转换为小写
            commodityDescription = commodityDescription.toLowerCase();

            //去除（(中文左括号)
            if (commodityDescription.contains("（"))
            {
                commodityDescription = commodityDescription.replaceAll("（","");
            }

            //去除）(中文右括号)
            if (commodityDescription.contains("）"))
            {
                commodityDescription = commodityDescription.replaceAll("）","");
            }

            //去除((英文左括号)
            if (commodityDescription.contains("("))
            {
                commodityDescription = commodityDescription.replaceAll("\\(","");
            }

            //去除)(英文右括号)
            if (commodityDescription.contains(")"))
            {
                commodityDescription = commodityDescription.replaceAll("\\)","");
            }

            //去除'(英文引号)
            if (commodityDescription.contains("'"))
            {
                commodityDescription = commodityDescription.replaceAll("'","");
            }

            //去除-(英文引号)
            if (commodityDescription.contains("-"))
            {
                commodityDescription = commodityDescription.replaceAll("-","");
            }

            //将中文的克替换为g
            if (commodityDescription.contains("克"))
            {
                commodityDescription = commodityDescription.replace("克", "g");
            }

            //将中文的 4段 替换为 四段
            if (commodityDescription.contains("4段"))
            {
                commodityDescription = commodityDescription.replace("4段","四段");
            }

            //将中文的 3段 替换为 三段
            if (commodityDescription.contains("3段"))
            {
                commodityDescription = commodityDescription.replace("3段","三段");
            }

            //将中文的 2段 替换为二段
            if (commodityDescription.contains("2段"))
            {
                commodityDescription = commodityDescription.replace("2段","二段");
            }

            //将中文的 1段 替换为 一段
            if (commodityDescription.contains("1段"))
            {
                commodityDescription = commodityDescription.replace("1段","一段");
            }

            commodityDescription = commodityDescription.trim();

            return commodityDescription;
        }

    }

    public static void main(String[] args) throws IOException {

        String fileDir = "D:/WmGlobalOrdersTagMining/WmOrders";
        String fileExt = "*";
        OrderExcel2DBCorrectCommodityDescription.file2DB(fileDir, fileExt);

        System.out.println("Finished...");
    }

}
