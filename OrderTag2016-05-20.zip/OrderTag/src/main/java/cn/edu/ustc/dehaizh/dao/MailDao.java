package cn.edu.ustc.dehaizh.dao;

import cn.edu.ustc.dehaizh.domain.Mail;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * Created by dehaizh on 2016/3/17.
 */
public class MailDao extends SimpleJdbcDaoSupport{

    /**
     * 获取从指定位置开始的的N条无法分类的记录
     * @param startPos
     * @param itemsPerPage
     * @return
     */
    public List<Mail> getLatestNConfusedMails(int startPos, int itemsPerPage )
    {
        String sql = "SELECT id,sentDate,mailSubject,hasRead  FROM tb_mail_myisam WHERE confused=1 ORDER BY sentDate DESC LIMIT ?,?";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
            public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                Mail mail = new Mail();

                mail.setId( rs.getInt(1) );
                mail.setSentDate( rs.getString(2) );
                mail.setMailSubject( rs.getString(3) );
                mail.setHasRead( rs.getInt(4) );
                return mail;
            }
        },
               startPos, itemsPerPage);
    }

    /**
     * 获取从指定位置开始(startPos)的itemsPerPage条记录
     * @param startPos
     * @param itemsPerPage
     * @return
     */
    public List<Mail> getLatestNProcessedMails(int startPos, int itemsPerPage )
    {
        String sql = "SELECT id,sentDate,mailSubject,hasRead  FROM tb_mail_myisam WHERE confused=0 ORDER BY sentDate DESC LIMIT ?,?";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
                    public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Mail mail = new Mail();

                        mail.setId( rs.getInt(1) );
                        mail.setSentDate( rs.getString(2) );
                        mail.setMailSubject( rs.getString(3) );
                        mail.setHasRead( rs.getInt(4) );
                        return mail;
                    }
                },
                startPos, itemsPerPage);

    }

    /***
     * 获取N条从mail.one.com站点收到的邮件
     * @param startPos
     * @param itemsPerPage
     * @return
     */
    public List<Mail> getLatestNReceivedMails(int startPos, int itemsPerPage )
    {
        String sql = "SELECT id,sentDate,mailSubject,hasRead  FROM tb_mail_myisam  ORDER BY sentDate DESC LIMIT ?,?";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
                    public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Mail mail = new Mail();

                        mail.setId( rs.getInt(1) );
                        mail.setSentDate( rs.getString(2) );
                        mail.setMailSubject( rs.getString(3) );
                        mail.setHasRead( rs.getInt(4) );
                        return mail;
                    }
                },
                startPos, itemsPerPage);

    }
    /**
     * 获取指定邮件的详细信息
     * @param mailId
     * @return
     */
    public Map getMailDetail(int mailId){

        String sql = "SELECT id,sentDate,mailFrom,mailSubject,mailContent FROM tb_mail_myisam WHERE id=?";
        return getSimpleJdbcTemplate().queryForMap(sql,mailId);
    }

    /**
     * 获取总的未正确分类的条目数目
     * @return
     */
    public int getNumOfConfusedMails() {
        String sql = "SELECT COUNT(*) FROM tb_mail_myisam WHERE confused=1";
        return getSimpleJdbcTemplate().queryForInt(sql);
    }

    /**
     * 获取总的正确分类的邮件数目
     * @return
     */
    public int getNumOfProcessedMails() {
        String sql = "SELECT COUNT(*) FROM tb_mail_myisam WHERE confused=0";
        return getSimpleJdbcTemplate().queryForInt(sql);

    }

    /**
     * 从mail.one.com收到的总的邮件数目
     * @return
     */
    public int getNumOfReceivedMails() {
        String sql = "SELECT COUNT(*) FROM tb_mail_myisam ";
        return getSimpleJdbcTemplate().queryForInt(sql);
    }

    /***
     * 将单个mailId标记为已读
     * @param mailId
     */
    public void mailMarkAsRead(int mailId) {
        String sql = "update tb_mail_myisam SET hasRead=1 WHERE id=?";
        getSimpleJdbcTemplate().update(sql,mailId);
    }

    /**
     * 批量将mailId标记为已读
     * @param params
     */
    public void mailMarkAsReadBatch(List<Object[]> params) {
        String sql = "update tb_mail_myisam SET hasRead=1 WHERE id=?";
        getSimpleJdbcTemplate().batchUpdate(sql, params );

    }

    public void mailMarkAsUnReadBatch(List<Object[]> params) {
        String sql = "update tb_mail_myisam SET hasRead=0 WHERE id=?";
        getSimpleJdbcTemplate().batchUpdate(sql, params );
    }

    /***
     * 添加新回复
     * @param params
     */
    public void addResponse(Object[] params) {
//        String sql = "INSERT INTO tb_reply(mailId,mailResponse,addReplyOperator,addReplyDate)\n" +
//                "VALUES(3400,'reply','dehaizh','2015-02-14 14:23:56')";
//        String sql = "INSERT INTO tb_reply(mailId,mailResponse,addReplyOperator,addReplyDate)\n" +
//                "VALUES(?, ?, ?, ?)\n" +
//                "ON DUPLICATE KEY UPDATE mailResponse = CONCAT_WS('<br/><br/>',mailResponse,VALUES(mailResponse));\n";
        String sql = "INSERT INTO tb_reply(mailId,mailResponse,addReplyOperator,addReplyDate)\n" +
                "VALUES(?, ?, ?, ?)\n" +
                "ON DUPLICATE KEY UPDATE mailResponse = VALUES(mailResponse);";

        getSimpleJdbcTemplate().update(sql,params);

    }

    /**
     * 获取前一天到今天没有
     * @return
     */
    public int getNumOfDailyConfusedMails() {
        String sql = "SELECT COUNT(*) FROM tb_mail_myisam WHERE sentDate>=DATE( (NOW() - INTERVAL 2 DAY) ) AND confused=1";
        return getSimpleJdbcTemplate().queryForInt(sql);
    }

    public int getNumOfDailyProcessedMails() {
        String sql = "SELECT COUNT(*) FROM tb_mail_myisam WHERE sentDate>=DATE( (NOW() - INTERVAL 2 DAY) ) AND confused=0 ";
        return getSimpleJdbcTemplate().queryForInt(sql);
    }

    /**
     * 获取每天需要处理的Confused Mails
     * @return
     */
    public List<Mail> getDailyConfusedMails() {

        String sql = "SELECT id,sentDate,mailSubject,hasRead,mailCategory  FROM tb_mail_myisam \n" +
                "WHERE sentDate>=DATE( (NOW() - INTERVAL 2 DAY) ) AND confused=1\n" +
                "ORDER BY sentDate DESC ";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
                    public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Mail mail = new Mail();

                        mail.setId( rs.getInt(1) );
                        mail.setSentDate( rs.getString(2) );
                        mail.setMailSubject( rs.getString(3) );
                        mail.setHasRead( rs.getInt(4) );
                        mail.setMailCategory( rs.getString(5) );
                        return mail;
                    }
                });
    }

    /**
     *更新confused=1为confused=0
     * @param mailId
     */
    public void uodateConfused2UnConfused(int mailId) {
        String sql = "UPDATE tb_mail_myisam SET confused=0 WHERE id=?";

        getSimpleJdbcTemplate().update(sql,mailId);
    }

    /***
     * 获取每天处理的邮件
     * @return
     */
    public List<Mail> getDailyProcessedMails() {

        String sql = "SELECT mail.id, mail.sentDate, mail.mailSubject, mail.mailContent, \n" +
                "mail.hasRead,mail.outerMailCategory, IFNULL(reply.mailResponse,''), \n" +
                "IFNULL(reply.addReplyOperator,''), IFNULL(reply.addReplyDate,''),mail.mailCategory  " +
                "FROM tb_mail_myisam mail LEFT JOIN tb_reply reply ON mail.id = reply.mailId " +
                "WHERE mail.sentDate>=DATE( (NOW() - INTERVAL 2 DAY) ) AND mail.confused=0 " +
                "ORDER BY mail.sentDate DESC ";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
            public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                Mail mail = new Mail();

                mail.setId( rs.getInt(1) );
                mail.setSentDate( rs.getString(2) );
                mail.setMailSubject( rs.getString(3) );
                mail.setContent(  rs.getString(4) );
                mail.setHasRead( rs.getInt(5));
                mail.setMailOuterCategory( rs.getString(6)  );
                mail.setResponse( rs.getString(7).replaceAll("\n","<br/>")  );
                mail.setAddReplyOperator(rs.getString(8));
                mail.setAddReplyDate( rs.getString(9)  );
                mail.setMailCategory(rs.getString(10)  );
                return mail;
            }
        });

    }

    /***
     * 每天已经处理的订单详情
     * @param mailId
     * @return
     */
    public Map getDailyProcessedMailDetail(int mailId) {
        String sql = "SELECT mail.id, mail.sentDate,mail.mailFrom, mail.mailSubject, mail.mailContent,  IFNULL(reply.mailResponse,'') as reply \n" +
                "FROM tb_mail_myisam mail LEFT JOIN tb_reply reply ON mail.id = reply.mailId \n" +
                "WHERE mail.id=?";
        return getSimpleJdbcTemplate().queryForMap(sql,mailId);
    }


    public List<Mail> getDailyProcessedMailsWithoutNoNeedReply() {
        String sql = "SELECT mail.id, mail.sentDate, mail.mailSubject, mail.mailContent, \n" +
                "mail.hasRead,mail.outerMailCategory, IFNULL(reply.mailResponse,''), \n" +
                "IFNULL(reply.addReplyOperator,''), IFNULL(reply.addReplyDate,''),mail.mailCategory  " +
                "FROM tb_mail_myisam mail LEFT JOIN tb_reply reply ON mail.id = reply.mailId " +
                "WHERE mail.sentDate>=DATE( (NOW() - INTERVAL 2 DAY) ) AND mail.confused=0  AND  mail.needReply=1 " +
                "ORDER BY mail.sentDate DESC ";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
            public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                Mail mail = new Mail();

                mail.setId( rs.getInt(1) );
                mail.setSentDate( rs.getString(2) );
                mail.setMailSubject( rs.getString(3) );
                mail.setContent(  rs.getString(4) );
                mail.setHasRead( rs.getInt(5));
                mail.setMailOuterCategory( rs.getString(6)  );
                mail.setResponse( rs.getString(7).replaceAll("\n","<br/>")  );
                mail.setAddReplyOperator(rs.getString(8));
                mail.setAddReplyDate( rs.getString(9)  );
                mail.setMailCategory( rs.getString(10) );
                return mail;
            }
        });

    }

    public int getNumOfDailyProcessedMailsWithoutNoNeedReply() {
        String sql = "SELECT COUNT(*) FROM tb_mail_myisam WHERE sentDate>=DATE( (NOW() - INTERVAL 2 DAY) ) AND confused=0 AND needReply=1 ";
        return getSimpleJdbcTemplate().queryForInt(sql);
    }

    /**
     * 获取邮件分类列表
     * @return
     */
    public List<String> getMailOuterCategory() {
        String sql = "SELECT DISTINCT OuterCategory FROM tb_mail_category";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<String>() {
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getString(1);
            }
        });
    }

    /**
     * 根据 mailCategory、开始日期、结束日期、以及邮件关键字来
     * 查找邮件
     * @param startDate
     * @param endDate
     * @param mailCategory
     * @param keyWord
     * @return
     */
    public List<Mail> getMailsByCategoryAndKeyWord(String startDate, String endDate, String mailCategory, String keyWord) {
//        String sql = "SELECT * FROM tb_mail_myisam WHERE  sentDate>='2016-04-01' AND sentDate<='2016-04-10' AND mailCategory='your e-mail to' AND mailContent LIKE '%invoice%'";
       String mailLike="%"+keyWord+"%";
        String sql = "SELECT id,sentDate,mailSubject,hasRead FROM tb_mail_myisam WHERE  sentDate>=? AND sentDate<=? AND outerMailCategory=? AND mailContent LIKE ? ORDER BY sentDate DESC";
        if(mailCategory.equals("ALL"))
        {
            sql = "SELECT id,sentDate,mailSubject,hasRead FROM tb_mail_myisam WHERE  sentDate>=? AND sentDate<=?  AND mailContent LIKE ? ORDER BY sentDate DESC";
            return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
                public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                    Mail mail = new Mail();

                    mail.setId( rs.getInt(1) );
                    mail.setSentDate( rs.getString(2) );
                    mail.setMailSubject( rs.getString(3) );
                    mail.setHasRead( rs.getInt(4) );

                    return mail;
                }
            },startDate,endDate,mailLike);
        }
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
            public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                Mail mail = new Mail();

                mail.setId( rs.getInt(1) );
                mail.setSentDate( rs.getString(2) );
                mail.setMailSubject( rs.getString(3) );
                mail.setHasRead( rs.getInt(4) );

                return mail;
            }
        },startDate,endDate,mailCategory,mailLike);
    }

    /**
     * 通过outerMailCategory来查询邮件信息
     * @param startDate
     * @param endDate
     * @param mailCategory
     * @return
     */
    public List<Mail> getMailsByCategory(String startDate, String endDate, String mailCategory) {
        String sql = "SELECT id,sentDate,mailSubject,hasRead FROM tb_mail_myisam WHERE  sentDate>=? AND sentDate<=? AND outerMailCategory=? ORDER BY sentDate DESC";
        if(mailCategory.equals("ALL"))
        {
            sql = "SELECT id,sentDate,mailSubject,hasRead FROM tb_mail_myisam WHERE  sentDate>=? AND sentDate<=? ORDER BY sentDate DESC";
            return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
                public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                    Mail mail = new Mail();

                    mail.setId( rs.getInt(1) );
                    mail.setSentDate( rs.getString(2) );
                    mail.setMailSubject( rs.getString(3) );
                    mail.setHasRead( rs.getInt(4) );

                    return mail;
                }
            },startDate,endDate);
        }
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
            public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                Mail mail = new Mail();

                mail.setId( rs.getInt(1) );
                mail.setSentDate( rs.getString(2) );
                mail.setMailSubject( rs.getString(3) );
                mail.setHasRead( rs.getInt(4) );

                return mail;
            }
        },startDate,endDate,mailCategory);
    }

    /**
     * 通过邮件内容关键字来查询邮件信息
     * @param startDate
     * @param endDate
     * @param keyWord
     * @return
     */
    public List<Mail> getMailsByKeyWord(String startDate, String endDate, String keyWord) {
       String mailLike = "%"+keyWord+"%";
        String sql = "SELECT id,sentDate,mailSubject,hasRead FROM tb_mail_myisam WHERE  sentDate>=? AND sentDate<=? AND mailContent LIKE ? ORDER BY sentDate DESC ";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
            public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                Mail mail = new Mail();

                mail.setId( rs.getInt(1) );
                mail.setSentDate( rs.getString(2) );
                mail.setMailSubject( rs.getString(3) );
                mail.setHasRead( rs.getInt(4) );

                return mail;
            }
        },startDate,endDate,mailLike);
    }

    /**
     * 通过邮件发件日期来查询邮件信息
     * @param startDate
     * @param endDate
     * @return
     */
    public List<Mail> getMailsByDate(String startDate, String endDate) {
        String sql = "SELECT id,sentDate,mailSubject,hasRead FROM tb_mail_myisam WHERE  sentDate>=? AND sentDate<=? ORDER BY sentDate DESC";
        return getSimpleJdbcTemplate().query(sql, new RowMapper<Mail>() {
            public Mail mapRow(ResultSet rs, int rowNum) throws SQLException {
                Mail mail = new Mail();

                mail.setId( rs.getInt(1) );
                mail.setSentDate( rs.getString(2) );
                mail.setMailSubject( rs.getString(3) );
                mail.setHasRead( rs.getInt(4) );

                return mail;
            }
        },startDate,endDate);
    }
}
