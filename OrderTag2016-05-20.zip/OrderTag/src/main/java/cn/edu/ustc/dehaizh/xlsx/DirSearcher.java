package cn.edu.ustc.dehaizh.xlsx;

import java.io.File;
import java.io.IOException;

import java.util.ArrayList;

public final class DirSearcher {
	//私有构造器增强不可实例化的能力
	private DirSearcher(){}
	
	//长度为0的空集合
	private static final ArrayList<String> EMPTY_DIR_LIST = new ArrayList<String>();
	
	/**
	 * 
	 * @param dirpath 指定目录的绝对路径
	 * @return	返回该目录下所有的子目录列表，是该目录的绝对路径，如果不存在子目录列表，则返回长度为0的集合
	 * @throws IOException
	 */
	public static ArrayList<String> getDirs(String dirpath) throws IOException
	{
		EMPTY_DIR_LIST.clear();
		ArrayList<String> dirNames = new ArrayList<String>();
		File dir = new File(dirpath);
		//不是合法的目录，抛出IOException
		if(!dir.isDirectory())
			throw new IOException("Invalid Directory "+dirpath);
		File[] fileTmp = dir.listFiles();
		for(File element:fileTmp)
		{
			if(element.isDirectory())
				dirNames.add(element.getAbsolutePath());	
		}
		return dirNames;
	}
	
	/**
	 * 检测指定的目录路经是否存在，合法的目录将会返回true，不合法的目录将会返回false
	 * @param pathname
	 * @return 如果是合法的路径，将会返回true
	 */
	public static boolean validDir(String pathname)
	{
		boolean ret = true;
		File dir = new File(pathname);
		if(!dir.isDirectory())
		{
			ret = false;
		}
		return ret;
		
	}
	
	public static void main(String[] args) throws IOException {
		String dirpath = "C:\\FileProcess\\OrderCheckCSVPF(ETAO)2\\ETAOCSVFiles";
		ArrayList<String> dirnames = DirSearcher.getDirs(dirpath);
		for(String element :dirnames)
		{
			System.err.println(element);
		}
		
	}
}
