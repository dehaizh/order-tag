package cn.edu.ustc.dehaizh.util;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * Created by dehaizh on 2016/3/17.
 */
@Transactional
public class DBCommonOperation extends SimpleJdbcDaoSupport implements IDBCommonOperation {
    /**
     * execute for update,insert,delete that without rerurns
     *
     * @param sql
     * @param params NamedParametered HashMap,such as:
     *               sql = INSERT INTO tb_mail(sentDate,mailSubject) VALUES(:sentDate,:mailSubject)
     */
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.REPEATABLE_READ )
    public void executeNonQuery(String sql, Map params) {

        getSimpleJdbcTemplate().update(sql, params);

    }

    /**
     * execute for select that with returns
     *
     * @param sql
     * @param params it is also NamedParametered HashMap
     * @return
     */
    @Transactional(propagation = Propagation.SUPPORTS, isolation = Isolation.READ_COMMITTED)
    public List executeQuery(String sql, Map params) {

        return getSimpleJdbcTemplate().query(sql, new RowMapper<Object[]>() {
            public Object[] mapRow(ResultSet rs, int rowNum) throws SQLException {

                int numOfCol = rs.getMetaData().getColumnCount();
                Object[] record = new Object[numOfCol];
                for(int i=0;i<numOfCol;++i) {
                    record[i] = rs.getObject(i + 1);
                }
                return record;
            }
        }, params);

    }

    /**
     * batch operation,such as dumping the csv file into db
     *
     * @param sql
     * @param params
     */
//    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.REPEATABLE_READ)
    public int[] batch(String sql, List<Object[]> params) {

        return getSimpleJdbcTemplate().batchUpdate(sql,params);
    }

}
