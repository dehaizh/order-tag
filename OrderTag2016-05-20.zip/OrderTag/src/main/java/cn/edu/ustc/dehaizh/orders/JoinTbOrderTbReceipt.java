package cn.edu.ustc.dehaizh.orders;

import cn.edu.ustc.dehaizh.util.DBCommonOperationWithoutJdbcDaoSupport;


/**
 * Created by dehaizh on 2016/5/3.
 */
public class JoinTbOrderTbReceipt {
    private static String JOIN_TB_ORDERS_RECEIPT_CALLABLE_SQL= "{call sp_join_orders_receipt()}";
    public static void joinTbOrderTbReceipt()
    {
        System.out.printf("--------------- %20s --------------------\r\n", "正在合并tb_orders和tb_receipt中的数据");
        DBCommonOperationWithoutJdbcDaoSupport.callNonQuery(JOIN_TB_ORDERS_RECEIPT_CALLABLE_SQL, null);

    }
    public static void main(String[] args) {

        JoinTbOrderTbReceipt.joinTbOrderTbReceipt();
        System.out.println("Finished...");

    }

}
