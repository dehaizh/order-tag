package cn.edu.ustc.dehaizh.domain;

/**
 * Created by root on 16-5-18.
 * 商品某一段时间的销售趋势
 */
public class ProductTrend {
    //获取某一段时间内的销量
    private String monthTime;
    //商品名称
    private String commodity;
    //商品总销量
    private Integer cnt;

    @Override
    public String toString() {
        return "ProductTrend{" +
                "monthTime='" + monthTime + '\'' +
                ", commodity='" + commodity + '\'' +
                ", cnt=" + cnt +
                '}';
    }

    public String getMonthTime() {
        return monthTime;
    }

    public void setMonthTime(String monthTime) {
        this.monthTime = monthTime;
    }

    public String getCommodity() {
        return commodity;
    }

    public void setCommodity(String commodity) {
        this.commodity = commodity;
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }
}
