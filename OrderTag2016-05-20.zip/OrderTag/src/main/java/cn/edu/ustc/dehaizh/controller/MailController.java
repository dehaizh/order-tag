package cn.edu.ustc.dehaizh.controller;

import cn.edu.ustc.dehaizh.domain.Mail;
import cn.edu.ustc.dehaizh.domain.User;
import cn.edu.ustc.dehaizh.service.MailGetService;
import hirondelle.date4j.DateTime;
import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Created by dehaizh on 2016/3/15.
 */
@Controller
public class MailController {

    private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Inject
    @Named("mailGetService")
    private MailGetService mailGetService;

    private int itemPerPage = 50;
    private int numOfConfusedMails;
    private int numOfProcessedMails;
    private int numOfReceivedMails;

    /**
     *  请求机器无法正确分类的邮件
     * @param model
     * @param startPos
     * @return
     */
    @RequestMapping(value = "/mail/confused")
    public String confusedMails(Model model,int startPos )
    {

        numOfConfusedMails = mailGetService.getNumOfConfusedMails();
//        int endPos = (startPos+itemPerPage)<numOfConfusedMails?(startPos+itemPerPage):numOfConfusedMails;
        int endPos = numOfConfusedMails;
        List<Mail> mails = mailGetService.getLatestNConfusedMails(startPos,numOfConfusedMails);
        model.addAttribute("confusedMails",mails);
        model.addAttribute("startPos",startPos+1);
        model.addAttribute("endPos", endPos );
        model.addAttribute("totalMails", numOfConfusedMails );

        return "main";
    }

    /**
     *  请求机器能够正确分类的邮件
     * @param model
     * @param startPos
     * @return
     */
    @RequestMapping(value = "/mail/processed")
    public String processedMails(Model model,int startPos )
    {

        numOfProcessedMails = mailGetService.getNumOfProcessedMails();
        int endPos = (startPos+itemPerPage)<numOfProcessedMails?(startPos+itemPerPage):numOfProcessedMails;
        List<Mail> mails = mailGetService.getLatestNProcessedMails(startPos, itemPerPage);
        model.addAttribute("confusedMails",mails);
        model.addAttribute("startPos",startPos+1);
        model.addAttribute("endPos", endPos );
        model.addAttribute("totalMails", numOfProcessedMails );

        return "processedMails";
    }

    /**
     * 从mail.one.com站点获取所有的mails
     * @param model
     * @param startPos
     * @return
     */
    @RequestMapping(value = "/mail/received")
    public String receivedMails(Model model,int startPos )
    {
        numOfReceivedMails = mailGetService.getNumOfReceivedMails();
        int endPos = (startPos+itemPerPage)<numOfReceivedMails?(startPos+itemPerPage):numOfReceivedMails;
        List<Mail> mails = mailGetService.getLatestNReceivedMails(startPos, itemPerPage);
        model.addAttribute("confusedMails",mails);
        model.addAttribute("startPos",startPos+1);
        model.addAttribute("endPos", endPos );
        model.addAttribute("totalMails", numOfReceivedMails );

        return "receivedMails";
    }

    /***
     * 使用路径变量来控制不同的请求参数,使用邮件ID作为参数来获取邮件的详细信息
     * @param mailId
     * @param model
     * @return
     */
    @RequestMapping(value = "/mail/mailDetails/{mailId}")
    public  String confusedMailDetails(@PathVariable int mailId,Model model )
    {
        System.out.println("进入/mail/mailDetails/");
        Map mail = mailGetService.getMailDetail(mailId);
        String mailContent = (String) mail.get("mailContent");

        //将文件中的\r\n(\n)换行换成html页面能够显示的<br/>换行
        mail.put("mailContent",mailContent.replaceAll("\n","<br/>"));
        model.addAttribute("mail",mail);

        return "message";
    }

    /***
     *
     * @param mailId 邮件id，该回复是针对该邮件的
     * @param model
     * @param response 回复的内容
     * @return
     */
    @RequestMapping("/mail/response/{mailId}")
    @ResponseBody
    public String mailResponse( @PathVariable int mailId,Model model,String response,HttpServletRequest request)
    {
        System.out.println("Mail Id: "+mailId +" Response: "+response);

        //        保存用户信息
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        Object[] params = new Object[4];
//        Date date = new Date();
//        String addReplyDate = dateTimeFormat.format(date);
        String addReplyOperator = user.getUsername();
        params[0] = mailId;
        params[1] = response;
        params[2] = addReplyOperator;
        //addReplyDate timestamp类型，设置为null就默认为插入值的时间
        params[3] = null;

        mailGetService.addResponse(params);

        //把该邮件的confused=1更新为confused=0
        mailGetService.updateConfused2UnConfused(mailId);

        return "Deliveried successfully";
    }

    @RequestMapping("/mail/updateRead")
    @ResponseBody
    public String updateReadStatus(String href)
    {
        System.out.println("update read status"+href);
        int mailId = -1;
        try {
            mailId = Integer.parseInt( href.substring(href.lastIndexOf("/")+1) );
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("MailId: "+mailId );

        //更新邮件为已读
        if(mailId>=0)
            mailGetService.mailMarkAsRead( mailId );

        return "SUCCESS";
    }

    /**
     * 通过ajax请求发送过来的批量标记为已读的邮件的序号
     * @param mailIds 是由commas分割的mailId的字符串，如 123,345,456
     * @return
     */
    @RequestMapping("/mail/markAsRead")
    @ResponseBody
    public String markAsRead(String mailIds)
    {
        System.out.println("mailIds: "+mailIds);
        String[] mailIdArr = mailIds.split(",");

        List<Object[]> params = new ArrayList<Object[]>();
        for(String mailId:mailIdArr) {
            Object[] record = new Object[1];
            record[0] = mailId;
            params.add(record);
        }

        //批量更新邮件状态
        if(params.size()>0)
        mailGetService.mailMarkAsReadBatch(params);

        return "SUCCESS";
    }

    /**
     * 批量更新邮件为未读
     * @param mailIds 有mailId用逗号分割的字符串，如 123,345,456
     * @return
     */
    @RequestMapping("/mail/markAsUnread")
    @ResponseBody
    public String markAsUnread(String mailIds)
    {
        System.out.println("mailIds: "+mailIds);
        String[] mailIdArr = mailIds.split(",");

        List<Object[]> params = new ArrayList<Object[]>();
        for(String mailId:mailIdArr) {
            Object[] record = new Object[1];
            record[0] = mailId;
            params.add(record);
        }

        //批量更新邮件状态
        if(params.size()>0)
            mailGetService.mailMarkAsUnReadBatch(params);

        return "SUCCESS";

    }


    /***
     * 邮件批量转发给指定的mailAddress
     * @param mailIds
     * @param forwardTo 由!!!分割的邮件地址列表
     * @return
     */
    @RequestMapping("/mail/forward")
    @ResponseBody
    public String forward(String mailIds, String forwardTo)
    {
        System.out.println("mailIds: "+mailIds);
        System.out.println("ForwardTo: "+forwardTo);


        return "SUCCESS";
    }

    /**
     * 用力检索前一天到今天所有的mails，进行分类
     * 已经处理的邮件
     * 还未处理的邮件
     * 需要回复的邮件
     *
     */
    @RequestMapping("/mail/dailyTask")
    public String dailyTask(Model model)
    {
        System.out.println("Daily Task");

        int numOfDailyConfusedMails = mailGetService.getNumOfDailyConfusedMails();
        int numOfDailyProcessedMailsWithoutNoNeedReply = mailGetService.getNumOfDailyProcessedMailsWithoutNoNeedReply();
        int numOfDailyProcessedMails = mailGetService.getNumOfDailyProcessedMails();

        model.addAttribute("numOfDailyConfusedMails",numOfDailyConfusedMails);
        model.addAttribute("numOfDailyProcessedMails",numOfDailyProcessedMails);
        model.addAttribute("numOfDailyProcessedMailsWithoutNoNeedReply",numOfDailyProcessedMailsWithoutNoNeedReply);

        return "dailyTask";
    }

    /**
     *
     * @param model
     * @return
     */
    @RequestMapping("/mail/dailyConfusedMails")
    public String dailyConfusedMails(Model model)
    {
//        int endPos = (startPos+itemPerPage)<numOfConfusedMails?(startPos+itemPerPage):numOfConfusedMails;
//        int endPos = numOfConfusedMails;
        List<Mail> mails = mailGetService.getDailyConfusedMails();
//        List<Mail> mails = mailGetService.getLatestNConfusedMails(startPos, numOfConfusedMails);
        model.addAttribute("confusedMails",mails);

        return "dailyConfusedMails";
    }

    @RequestMapping("/mail/dailyProcessedMails")
    public String dailyProcessedMails(Model model)
    {
        List<Mail> mails = mailGetService.getDailyProcessedMails();
//        List<Mail> mails = mailGetService.getLatestNConfusedMails(startPos, numOfConfusedMails);
        model.addAttribute("mails",mails);

        return "dailyProcessedMails";
    }


    @RequestMapping("/mail/dailyProcessedMailsWithoutNoNeedReply")
    public String dailyProcessedMailsWithoutNoNeedReply(Model model)
    {
//        List<Mail> mails = mailGetService.getDailyProcessedMails();
        List<Mail> mails = mailGetService.getDailyProcessedMailsWithoutNoNeedReply();
//        List<Mail> mails = mailGetService.getLatestNConfusedMails(startPos, numOfConfusedMails);
        model.addAttribute("mails",mails);

        return "dailyProcessedMailsWithoutNoNeedReply";
    }

    @RequestMapping(value = "/mail/dailyProcessedMailDetail/{mailId}")
    public  String dailyProcessedMailDetail(@PathVariable int mailId,Model model )
    {
        System.out.println("进入/mail/dailyProcessedMailDetail");
        Map mail = mailGetService.getDailyProcessedMailDetail(mailId);
        //将回复信息中的<br/>替换为\r\n
        String reply= (String)mail.get("reply");
        reply = reply.replaceAll("<br/>","\n");
        mail.put("reply",reply);

        String mailContent = (String) mail.get("mailContent");
        //将文件中的\r\n(\n)换行换成html页面能够显示的<br/>换行
        mail.put("mailContent",mailContent.replaceAll("\n","<br/>"));
        model.addAttribute("mail",mail);

        return "dailyProcessedMailDetail";
    }

    @RequestMapping(value = "/mail/finder")
    public  String finder(Model model )
    {
        System.out.println("进入/mail/finder/");
//        Map mail = mailGetService.getDailyProcessedMailDetail(mailId);
//        String mailContent = (String) mail.get("mailContent");
//        //将文件中的\r\n(\n)换行换成html页面能够显示的<br/>换行
//        mail.put("mailContent",mailContent.replaceAll("\n","<br/>"));
//        model.addAttribute("mail",mail);

        List<String> mailOuterCategory = mailGetService.getMailOuterCategory();
        mailOuterCategory.add(0,"ALL");
        model.addAttribute("mailOuterCategory",mailOuterCategory);
        return "finder";
    }

    /**
     * 查询
     * @param model
     * @return
     */
    @RequestMapping(value = "/mail/finderQuery")
    @ResponseBody
    public  String finderQuery(Model model, String startDate, String endDate, String mailCategory, String keyWord )
    {
        System.out.println("进入/mail/finderQuery");
        System.out.println("StartDate: "+startDate+" EndDate: "+endDate+ " MailCategory"+mailCategory+" KeyWord: "+keyWord);
        //startDate有问题
        if(!(startDate!=null && startDate.length()>0))
        {
            startDate = "NOW()-INTERVAL 1 MONTH"; //开始时间设置为一个月前
        }else{
            startDate = convertDate2YYYYMMDD(startDate);
        }

        //endDate有问题
        if(!(endDate!=null && endDate.length()>0))
        {
            endDate = "NOW()"; //结束时间设置为当前时间
        }else{
            endDate = convertDate2YYYYMMDD(endDate);
        }

        System.out.println("After Process__StartDate: "+startDate+" EndDate: "+endDate+ " MailCategory"+mailCategory+" KeyWord: "+keyWord);

        //结果集
        List<Mail> mails = null;
        //所有的条件都满足

        if(mailCategory!=null && mailCategory.length()>0 )
        {
            if(keyWord!=null&&keyWord.length()>0)
                mails = mailGetService.getMailsByCategoryAndKeyWord(startDate, endDate, mailCategory, keyWord);
            else
                mails = mailGetService.getMailsByCategory(startDate, endDate, mailCategory);
        }else{
            if(keyWord!=null && keyWord.length()>0)
                mails = mailGetService.getMailsByKeyWord(startDate,endDate, keyWord);
            else
                mails = mailGetService.getMailsByDate(startDate,endDate);
        }

        StringBuilder resultBuilder = new StringBuilder();
        resultBuilder.append(" <table width='96%'>\n" +
                "            <thead>\n" +
                "            <tr>\n" +
                "                <th width='10px'>Box</th>\n" +
                "                <th>SentDate MailSubject </th>\n" +
                "            </tr>\n" +
                "            </thead>\n" +
                "            <tbody>");

        //使用getSimpleJdbcTemplate获取数据时，当数据为结果为空时，他不是返回NULL，而是返回一个长度为0的数组或者集合
        //需要特别注意
        if(mails!=null&&mails.size()>0)
        {
//            resultBuilder.append("<tr><td colspan='2' style='color:red;'><STRONG>There are ").append(mails.size()).append(" Record(s) </STRONG>&nbsp;&nbsp;&nbsp;&nbsp; <a href='/mail-autoreply/mail/queryResult/download?startDate=").append(startDate).append("&endDate=").append(endDate).append("&mailCategory=").append(mailCategory).append("&keyWord=").append(keyWord).append("' >Download QueryResult(s)</a></td></tr>");
            resultBuilder.append("<tr><td colspan='2' style='color:red;'><STRONG>本次查询仅提供前 ").append(mails.size()).append(" 个记录</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;").append("</td></tr>");
            for(Mail mail:mails)
            {
                resultBuilder.append(" <tr><td class='user-name'><input type='checkbox' name='chkItem' id='");
                resultBuilder.append(mail.getId());
                resultBuilder.append("' /></td><td class='user-name'>\n" +
                        "                <a  class='hrefCss' href='/mail-autoreply/mail/mailDetails/");
                resultBuilder.append(mail.getId());
                resultBuilder.append("' target='messageFrame'  id='"+mail.getId()+"href'\n" +
                        "                    style='color:");
                if(mail.getHasRead()==1)
                    resultBuilder.append(" lightslategray");
                else
                    resultBuilder.append("green");
                resultBuilder.append("'  > ");
                resultBuilder.append(mail.getSentDate());
                resultBuilder.append(" &nbsp;&nbsp; ");
                resultBuilder.append(mail.getMailSubject());
                resultBuilder.append(" </a>  </td></tr>");
            }

        }

        if(mails==null||mails.size()==0)
            resultBuilder.append("<tr><td colspan=2 style='color:red;'><STRONG>Sorry,There is no result,Please try again</STRONG></td></tr>");

        resultBuilder.append("    </tbody>\n" +
                "        </table>");
        return resultBuilder.toString();
    }

    private String convertDate2YYYYMMDD(String startDate) {
        StringBuilder builder = new StringBuilder();
        //开始日期是 月/日/年 的形式
        String[] tmps = startDate.split("/");
        return builder.append(tmps[2]).append("-").append(tmps[0]).append("-").append(tmps[1]).toString();
    }

    @RequestMapping(value = "/mail/queryResult/download")
    public  ResponseEntity<byte[]> queryResultDownload(Model model, HttpServletRequest request ,String startDate, String endDate, String mailCategory, String keyWord ) throws IOException
    {
        System.out.println("/mail/queryResult/download");
        System.out.println("StartDate:"+startDate+" EndDate:"+endDate+" MailCategory: "+mailCategory+" KeyWord:"+keyWord);

        String filename = DateTime.now(TimeZone.getDefault()).format("YYYYMMDD-hh-mm-ss")+".zip";
        String filepath = request.getSession().getServletContext().getRealPath("/WEB-INF/download/bottom.vm");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", filename);
        return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray( FileUtils.getFile(filepath) ),
                headers, HttpStatus.CREATED);


//        return "download";
    }

    private void zip(String destDir) throws IOException {
        byte[] buffer = new byte[1024];

        //生成的ZIP文件名为Demo.zip

        String strZipName = "e:/Demo.zip";

        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(strZipName));

        //需要同时下载的两个文件result.txt ，source.txt

        File[] file1 = {new File("e:/a.txt"),new File("e:/b.txt"),new File("e:/aa.txt"),new File("e:/bb.txt")};

        for(int i=0;i<file1.length;i++) {

            FileInputStream fis = new FileInputStream(file1[i]);

            out.putNextEntry(new ZipEntry(file1[i].getName()));

            int len;

            //读入需要下载的文件的内容，打包到zip文件

            while((len = fis.read(buffer))>0) {

                out.write(buffer,0,len);

            }

            out.closeEntry();

            fis.close();

        }

        out.close();

        System.out.println("生成Demo.zip成功");
    }

}
