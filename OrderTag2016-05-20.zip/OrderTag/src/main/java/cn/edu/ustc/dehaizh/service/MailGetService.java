package cn.edu.ustc.dehaizh.service;

import cn.edu.ustc.dehaizh.dao.MailDao;
import cn.edu.ustc.dehaizh.domain.Mail;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Map;

/**
 * Created by dehaizh on 2016/3/17.
 */
@Service("mailGetService")
public class MailGetService {
    @Inject
    @Named(value = "mailDao")
    private MailDao mailDao;


    /***
     * 请求机器无法正确分类的邮件
     * @param startPos
     * @param itemsPerPage
     * @return
     */
    public List<Mail> getLatestNConfusedMails(int startPos,int itemsPerPage)
    {
        return mailDao.getLatestNConfusedMails(startPos,itemsPerPage);
    }

    /***
     * 获取从指定位置开始的N条已经处理过的邮件
     * @param startPos
     * @param itemsPerPage
     * @return
     */
    public List<Mail> getLatestNProcessedMails(int startPos,int itemsPerPage)
    {
        return mailDao.getLatestNProcessedMails(startPos, itemsPerPage);
    }

    /**
     *获取从one.mail.com站点收到的指定书目的邮件
     * @param startPos
     * @param itemsPerPage
     * @return
     */
    public List<Mail> getLatestNReceivedMails(int startPos,int itemsPerPage)
    {
        return mailDao.getLatestNReceivedMails(startPos, itemsPerPage);
    }

    /***
     * 获取指定mailId邮件的详细信息
     * @param mailId
     * @return
     */
    public Map getMailDetail(int mailId)
    {
        return mailDao.getMailDetail(mailId);
    }

    /**
     * 获取总的无法正确分类的邮件数目
     * @return
     */
    public int getNumOfConfusedMails() {
        return mailDao.getNumOfConfusedMails();
    }

    /***
     * 机器能够正确处理的邮件数目
     * @return
     */
    public int getNumOfProcessedMails() {
        return mailDao.getNumOfProcessedMails();
    }

    /***
     * 机器收到的邮件总数目
     *
     * @return
     */
    public int getNumOfReceivedMails() {

        return mailDao.getNumOfReceivedMails();
    }

    /***
     * 标记单一邮件为已读
     * @param mailId
     */
    public void mailMarkAsRead(int mailId) {
        mailDao.mailMarkAsRead(mailId);
    }

    /***
     * 批量标记邮件为已读
     * @param params
     */
    public void mailMarkAsReadBatch(List<Object[]> params) {
        mailDao.mailMarkAsReadBatch(params);
    }

    /***
     * 批量标记邮件为未读
     * @param params
     */
    public void mailMarkAsUnReadBatch(List<Object[]> params) {
        mailDao.mailMarkAsUnReadBatch(params);

    }

    /**
     * 添加邮件回复信息
     * @param params
     */
    public void addResponse(Object[] params) {
        mailDao.addResponse(params);
    }

    public int getNumOfDailyConfusedMails() {

        return mailDao.getNumOfDailyConfusedMails();
    }

    public int getNumOfDailyProcessedMails() {
        return  mailDao.getNumOfDailyProcessedMails();
    }

    /**
     * 获取每天需要处理的Confused Mails的详情
     * @return
     */
    public List<Mail> getDailyConfusedMails() {
        return mailDao.getDailyConfusedMails();
    }

    /**
     * 将confused=1更新为congfused=0
     * @param mailId
     */
    public void updateConfused2UnConfused(int mailId) {
        mailDao.uodateConfused2UnConfused(mailId);
    }

    /**
     *获取每天已经处理的
     * @return
     */
    public List<Mail> getDailyProcessedMails() {

        return  mailDao.getDailyProcessedMails();
    }

    public Map getDailyProcessedMailDetail(int mailId) {
        return mailDao.getDailyProcessedMailDetail(mailId);
    }

    public List<Mail> getDailyProcessedMailsWithoutNoNeedReply() {

        return  mailDao.getDailyProcessedMailsWithoutNoNeedReply();
    }

    public int getNumOfDailyProcessedMailsWithoutNoNeedReply() {
        return mailDao.getNumOfDailyProcessedMailsWithoutNoNeedReply();
    }

    /**
     * 获取邮件的类别，这里是外部类别，也就是给客户看的类别
     * 对应于tb_mail_myisam表中的outerMailCategory
     * @return
     */
    public List<String> getMailOuterCategory() {
        return mailDao.getMailOuterCategory();
    }

    /**
     * 通过邮件类型（outerMailCategory）和邮件关键字来查询邮件信息
     * @param startDate
     * @param endDate
     * @param mailCategory
     * @param keyWord
     * @return
     */
    public List<Mail> getMailsByCategoryAndKeyWord(String startDate, String endDate, String mailCategory, String keyWord) {
        return mailDao.getMailsByCategoryAndKeyWord(startDate, endDate, mailCategory, keyWord );
    }

    public List<Mail> getMailsByCategory(String startDate, String endDate, String mailCategory) {
        return mailDao.getMailsByCategory(startDate,endDate,mailCategory);
    }

    public List<Mail> getMailsByKeyWord(String startDate, String endDate, String keyWord) {
        return  mailDao.getMailsByKeyWord(startDate,endDate,keyWord);
    }

    public List<Mail> getMailsByDate(String startDate, String endDate) {
        return mailDao.getMailsByDate(startDate, endDate);
    }

}
