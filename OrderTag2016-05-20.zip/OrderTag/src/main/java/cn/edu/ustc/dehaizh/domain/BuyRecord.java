package cn.edu.ustc.dehaizh.domain;

/**
 * Created by root on 16-5-10.
 */
public class BuyRecord {
    private String commodityDescription;
    private Integer cnt;
    private Integer amount;
    private Integer weight;

    private String receiverAddress;
    private String  reviewDateTime;


    public BuyRecord(String commodityDescription, Integer cnt, Integer amount, Integer weight) {
        this.commodityDescription = commodityDescription;
        this.cnt = cnt;
        this.amount = amount;
        this.weight = weight;
    }

    public BuyRecord() {
    }

    public String getCommodityDescription() {
        return commodityDescription;
    }

    public void setCommodityDescription(String commodityDescription) {
        this.commodityDescription = commodityDescription;
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public String getReceiverAddress() {
        return receiverAddress;
    }

    public void setReceiverAddress(String receiverAddress) {
        this.receiverAddress = receiverAddress;
    }

    public String getReviewDateTime() {
        return reviewDateTime;
    }

    public void setReviewDateTime(String reviewDateTime) {
        this.reviewDateTime = reviewDateTime;
    }
}
